"""
資料讀取模組：將第一階段匯出的 JSON 反序列化為 JointFrame 序列，
供第二階段生物力學計算模組使用。
"""
from __future__ import annotations

import json
import logging
from pathlib import Path

from .joint_extractor import JointFrame, JointPoint

logger = logging.getLogger(__name__)


def load_joint_sequence(path: Path) -> list[JointFrame]:
    """
    讀取第一階段匯出的關節序列 JSON 檔案。

    Args:
        path: JSON 檔案路徑。

    Returns:
        還原後的 JointFrame 序列，依原始 frame_id 順序排列。

    Raises:
        FileNotFoundError: 檔案不存在時拋出。
        ValueError: JSON 格式不符預期結構時拋出。
    """
    if not path.exists():
        raise FileNotFoundError(f"找不到關節序列檔案: {path}")

    with path.open(encoding="utf-8") as f:
        payload = json.load(f)

    if "frames" not in payload:
        raise ValueError(f"JSON 檔案缺少必要欄位 'frames': {path}")

    frames: list[JointFrame] = []
    for raw_frame in payload["frames"]:
        joints = {
            name: JointPoint(x=values[0], y=values[1], confidence=values[2])
            for name, values in raw_frame.get("joints", {}).items()
        }
        frames.append(
            JointFrame(
                frame_id=raw_frame["frame_id"],
                timestamp=raw_frame["timestamp"],
                joints=joints,
                person_detected=raw_frame.get("person_detected", False),
                multi_person_warning=raw_frame.get("multi_person_warning", False),
            )
        )

    logger.info("已讀取關節序列: path=%s, frame_count=%d", path, len(frames))
    return frames
