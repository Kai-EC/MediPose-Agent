"""
文件切片模組（Document Chunking）。

【中文切片的特殊考量】英文 NLP 常見的「固定 token 寬度切片」直接套用在
中文語料上容易在句子中間斷開（中文字詞之間無空白可供斷詞參考）。本模組
改採「字元數近似 token 數 + 優先在句界符號處斷句」的混合策略：先以
chunk_size_chars 為軟性上限累積句子，超過上限時才切斷，並盡量讓切點落在
句號／問號／驚嘆號／換行處，減少語意被攔腰截斷的機率。
"""
from __future__ import annotations

import logging
import re
import uuid
from dataclasses import dataclass

from ..config import ChunkingConfig

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class DocumentChunk:
    """單一文件切片。"""

    chunk_id: str
    text: str
    source: str
    chunk_index: int


def _split_into_sentences(text: str, boundary_chars: tuple[str, ...]) -> list[str]:
    """依句界符號將文字切成句子列表（保留句界符號於句尾）。"""
    pattern = "([" + re.escape("".join(boundary_chars)) + "])"
    pieces = re.split(pattern, text)

    sentences: list[str] = []
    buffer = ""
    for piece in pieces:
        buffer += piece
        if piece in boundary_chars:
            if buffer.strip():
                sentences.append(buffer)
            buffer = ""
    if buffer.strip():
        sentences.append(buffer)

    return sentences


def chunk_text(
    text: str, source: str, config: ChunkingConfig | None = None
) -> list[DocumentChunk]:
    """
    將長文本切割為帶重疊的語意片段。

    Args:
        text: 原始文本內容。
        source: 來源文件識別名稱（如檔名），寫入每個切片供溯源使用。
        config: 切片設定，預設使用 ChunkingConfig() 預設值。

    Returns:
        切片列表；輸入為空字串時回傳空列表。

    Raises:
        ValueError: chunk_overlap_chars 大於等於 chunk_size_chars 時拋出
            （重疊量過大會導致切片無法正常前進）。
    """
    cfg = config or ChunkingConfig()
    if cfg.chunk_overlap_chars >= cfg.chunk_size_chars:
        raise ValueError(
            f"chunk_overlap_chars ({cfg.chunk_overlap_chars}) 必須小於 "
            f"chunk_size_chars ({cfg.chunk_size_chars})"
        )

    if not text.strip():
        return []

    sentences = _split_into_sentences(text, cfg.sentence_boundary_chars)
    if not sentences:
        sentences = [text]

    chunks: list[DocumentChunk] = []
    current = ""
    chunk_index = 0

    def _flush(buffer: str) -> str:
        """將目前累積的 buffer 切成一個 chunk，並回傳供下一段使用的重疊尾段。"""
        nonlocal chunk_index
        if not buffer.strip():
            return ""
        chunks.append(
            DocumentChunk(
                chunk_id=f"{source}_{uuid.uuid4().hex[:8]}",
                text=buffer.strip(),
                source=source,
                chunk_index=chunk_index,
            )
        )
        chunk_index += 1
        return buffer[-cfg.chunk_overlap_chars :] if cfg.chunk_overlap_chars > 0 else ""

    for sentence in sentences:
        if len(current) + len(sentence) <= cfg.chunk_size_chars:
            current += sentence
            continue

        if current:
            current = _flush(current) + sentence
        else:
            current = sentence

        # 單一句子本身就超過 chunk_size（罕見但須防呆），強制依字元數硬切
        while len(current) > cfg.chunk_size_chars:
            head, current = current[: cfg.chunk_size_chars], current[cfg.chunk_size_chars :]
            current = _flush(head) + current

    _flush(current)

    logger.info("文件 %s 已切割為 %d 個片段", source, len(chunks))
    return chunks
