"""
RAG 檢索器模組。

整合 Embedding 模型與向量索引，對外提供「建立索引」與「查詢」兩個介面，
上層模組不需關心底層使用哪一種 Embedding 後端或向量索引實作。
"""
from __future__ import annotations

import logging
from typing import Optional

from ..config import EmbeddingConfig, RetrievalConfig
from .document_loader import DocumentChunk
from .embeddings import EmbeddingModel, create_embedding_model
from .vector_store import FaissVectorStore, RetrievedChunk

logger = logging.getLogger(__name__)


class Retriever:
    """RAG 檢索器：封裝索引建立與相似度查詢。"""

    def __init__(
        self,
        embedding_model: Optional[EmbeddingModel] = None,
        embedding_config: Optional[EmbeddingConfig] = None,
        retrieval_config: Optional[RetrievalConfig] = None,
    ) -> None:
        """
        Args:
            embedding_model: 已建立的 Embedding 模型實例；若為 None，
                依 embedding_config 自動建立。
            embedding_config: Embedding 設定，僅在 embedding_model 為 None 時使用。
            retrieval_config: 檢索設定（Top-K、相似度門檻）。
        """
        self._embedding_model = embedding_model or create_embedding_model(embedding_config)
        self._retrieval_config = retrieval_config or RetrievalConfig()
        self._vector_store: Optional[FaissVectorStore] = None

    def build_index(self, chunks: list[DocumentChunk]) -> None:
        """
        以文件片段列表建立檢索索引。

        Args:
            chunks: 文件切片列表。

        Raises:
            ValueError: chunks 為空時拋出。
        """
        if not chunks:
            raise ValueError("文件片段列表不可為空，無法建立索引")

        texts = [chunk.text for chunk in chunks]
        self._embedding_model.fit(texts)
        vectors = self._embedding_model.embed(texts)

        self._vector_store = FaissVectorStore(dimension=self._embedding_model.dimension)
        self._vector_store.add(vectors, chunks)

    def query(self, query_text: str, top_k: Optional[int] = None) -> list[RetrievedChunk]:
        """
        依查詢文字檢索最相關的文件片段。

        Args:
            query_text: 查詢文字（如依力學指標組成的查詢句）。
            top_k: 回傳結果數，預設使用 RetrievalConfig.top_k。

        Returns:
            依相似度排序、且相似度高於 min_similarity 門檻的檢索結果。

        Raises:
            RuntimeError: 尚未呼叫 build_index() 時拋出。
        """
        if self._vector_store is None:
            raise RuntimeError("尚未呼叫 build_index()，無法執行檢索")

        query_vector = self._embedding_model.embed([query_text])[0]
        k = top_k if top_k is not None else self._retrieval_config.top_k
        results = self._vector_store.search(query_vector, k)

        filtered = [
            r for r in results if r.similarity >= self._retrieval_config.min_similarity
        ]
        if len(filtered) < len(results):
            logger.debug(
                "%d 筆檢索結果因相似度低於門檻 (%.3f) 被過濾",
                len(results) - len(filtered), self._retrieval_config.min_similarity,
            )

        return filtered
