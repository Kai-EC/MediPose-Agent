"""
文字向量化模組。

提供兩種可替換的 Embedding 後端：

- `TfidfEmbedding`：基於字元 n-gram 的 TF-IDF（不需任何預訓練模型下載，
  純本機可跑），採字元級而非詞級 n-gram，原因是中文字詞間無空白可供
  斷詞，且醫學專有名詞常不在通用斷詞器字典中；字元 n-gram 對此較穩健。
  做為本機可測試的檢索基準（baseline），亦可作為 LLM 服務不可用時的
  降級方案。
- `SentenceTransformerEmbedding`：正式環境使用的語意 Embedding，
  需另行下載預訓練模型（延遲匯入，避免無相關需求時強制相依）。

兩者皆實作相同的 `EmbeddingModel` 介面，上層檢索邏輯不需關心實際後端。
"""
from __future__ import annotations

import logging
from typing import Protocol, runtime_checkable

import numpy as np

from ..config import EmbeddingConfig

logger = logging.getLogger(__name__)


@runtime_checkable
class EmbeddingModel(Protocol):
    """文字向量化模型的統一介面。"""

    def fit(self, corpus: list[str]) -> None:
        """以語料庫訓練/初始化向量化器（預訓練語意模型可為無操作）。"""
        ...

    def embed(self, texts: list[str]) -> np.ndarray:
        """將文字列表轉換為向量陣列，shape=(len(texts), dimension)。"""
        ...

    @property
    def dimension(self) -> int:
        """向量維度。"""
        ...


class TfidfEmbedding:
    """基於字元 n-gram 的 TF-IDF 向量化器。"""

    def __init__(self, max_features: int = 4096) -> None:
        from sklearn.feature_extraction.text import TfidfVectorizer

        self._vectorizer = TfidfVectorizer(
            max_features=max_features, analyzer="char", ngram_range=(2, 4)
        )
        self._is_fitted = False

    def fit(self, corpus: list[str]) -> None:
        """
        Args:
            corpus: 用於建立詞彙表的語料庫（通常為所有文件切片）。

        Raises:
            ValueError: 語料庫為空時拋出。
        """
        if not corpus:
            raise ValueError("語料庫不可為空")
        self._vectorizer.fit(corpus)
        self._is_fitted = True
        logger.info("TfidfEmbedding 已完成訓練，詞彙表大小=%d", len(self._vectorizer.vocabulary_))

    def embed(self, texts: list[str]) -> np.ndarray:
        """
        Raises:
            RuntimeError: 尚未呼叫 fit() 時拋出。
        """
        if not self._is_fitted:
            raise RuntimeError("TfidfEmbedding 尚未呼叫 fit()，無法進行向量化")
        matrix = self._vectorizer.transform(texts)
        return matrix.toarray().astype(np.float32)

    @property
    def dimension(self) -> int:
        if not self._is_fitted:
            raise RuntimeError("TfidfEmbedding 尚未呼叫 fit()，維度尚未確定")
        return len(self._vectorizer.vocabulary_)


class SentenceTransformerEmbedding:
    """正式環境使用的語意 Embedding（需另行下載預訓練模型）。"""

    def __init__(self, model_name: str) -> None:
        """
        Args:
            model_name: HuggingFace 模型名稱，建議使用繁中優化的小型模型，
                如 'BAAI/bge-small-zh-v1.5'。

        Raises:
            ImportError: 未安裝 sentence-transformers 套件時拋出。
        """
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as exc:
            raise ImportError(
                "未安裝 sentence-transformers 套件，請執行: "
                "pip install sentence-transformers"
            ) from exc

        self._model = SentenceTransformer(model_name)
        logger.info("SentenceTransformerEmbedding 已載入模型: %s", model_name)

    def fit(self, corpus: list[str]) -> None:
        """預訓練語意模型不需額外訓練，此方法為無操作（介面相容用）。"""
        return None

    def embed(self, texts: list[str]) -> np.ndarray:
        return self._model.encode(texts, convert_to_numpy=True).astype(np.float32)

    @property
    def dimension(self) -> int:
        return int(self._model.get_sentence_embedding_dimension())


def create_embedding_model(config: EmbeddingConfig | None = None) -> EmbeddingModel:
    """
    依設定建立對應的 Embedding 模型實例。

    Args:
        config: Embedding 設定，預設使用 EmbeddingConfig() 預設值。

    Returns:
        對應後端的 EmbeddingModel 實例。

    Raises:
        ValueError: backend 設定值不支援時拋出。
    """
    cfg = config or EmbeddingConfig()
    if cfg.backend == "tfidf":
        return TfidfEmbedding(max_features=cfg.max_features)
    if cfg.backend == "sentence_transformer":
        return SentenceTransformerEmbedding(model_name=cfg.model_name)
    raise ValueError(f"不支援的 embedding backend: {cfg.backend}")
