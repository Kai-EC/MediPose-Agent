"""
向量索引模組（FAISS 封裝）。

採用內積索引（IndexFlatIP）並對所有向量做 L2 正規化，
使內積等價於餘弦相似度，避免向量長度（如 TF-IDF 因文字長度差異）
影響相似度排序的公平性。
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

import numpy as np

from .document_loader import DocumentChunk

logger = logging.getLogger(__name__)

_NORM_EPSILON = 1e-12


@dataclass(frozen=True, slots=True)
class RetrievedChunk:
    """檢索結果：文件片段與其相似度分數。"""

    chunk: DocumentChunk
    similarity: float


def _normalize_rows(vectors: np.ndarray) -> np.ndarray:
    """對每一列向量做 L2 正規化，避免零向量造成除以零。"""
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    norms = np.maximum(norms, _NORM_EPSILON)
    return vectors / norms


class FaissVectorStore:
    """FAISS 向量索引封裝，提供加入與相似度檢索功能。"""

    def __init__(self, dimension: int) -> None:
        """
        Args:
            dimension: 向量維度，須與後續加入的向量維度一致。

        Raises:
            ValueError: dimension 不為正整數時拋出。
        """
        if dimension <= 0:
            raise ValueError(f"dimension 必須為正整數，收到: {dimension}")

        import faiss

        self._dimension = dimension
        self._index = faiss.IndexFlatIP(dimension)
        self._chunks: list[DocumentChunk] = []

    def add(self, vectors: np.ndarray, chunks: list[DocumentChunk]) -> None:
        """
        將向量與對應的文件片段加入索引。

        Args:
            vectors: shape=(N, dimension) 的向量陣列。
            chunks: 與向量一一對應的文件片段列表，長度須與 vectors 列數相同。

        Raises:
            ValueError: 向量維度不符，或 vectors 與 chunks 數量不一致時拋出。
        """
        if vectors.ndim != 2 or vectors.shape[1] != self._dimension:
            raise ValueError(
                f"向量維度不符，預期 (N, {self._dimension})，實際收到 shape={vectors.shape}"
            )
        if len(vectors) != len(chunks):
            raise ValueError(
                f"向量數量 ({len(vectors)}) 與片段數量 ({len(chunks)}) 不一致"
            )

        normalized = _normalize_rows(vectors.astype(np.float32))
        self._index.add(normalized)
        self._chunks.extend(chunks)
        logger.info("已加入 %d 筆向量至索引，目前總數=%d", len(chunks), len(self._chunks))

    def search(self, query_vector: np.ndarray, top_k: int) -> list[RetrievedChunk]:
        """
        檢索與查詢向量最相似的文件片段。

        Args:
            query_vector: shape=(dimension,) 的查詢向量。
            top_k: 回傳的最大結果數。

        Returns:
            依相似度由高到低排序的檢索結果列表（可能少於 top_k，
            若索引內片段總數不足）。
        """
        if len(self._chunks) == 0:
            logger.warning("索引為空，無法執行檢索")
            return []

        query = _normalize_rows(query_vector.reshape(1, -1).astype(np.float32))
        actual_top_k = min(top_k, len(self._chunks))
        similarities, indices = self._index.search(query, actual_top_k)

        results: list[RetrievedChunk] = []
        for similarity, idx in zip(similarities[0], indices[0]):
            if idx < 0:  # FAISS 結果不足 top_k 時以 -1 填充
                continue
            results.append(RetrievedChunk(chunk=self._chunks[idx], similarity=float(similarity)))

        return results

    def __len__(self) -> int:
        return len(self._chunks)
