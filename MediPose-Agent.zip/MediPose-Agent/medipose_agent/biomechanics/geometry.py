"""
向量幾何運算模組。

將時間序列關節座標轉換為關節夾角，採用向量內積公式：

    BA = A - B,  BC = C - B
    theta = arccos( (BA . BC) / (|BA| |BC|) )

其中 B 為頂點關節（如膝關節），A、C 為相鄰的近端/遠端關節（如髖、踝）。
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

import numpy as np

from ..joint_extractor import JointFrame, JointPoint

logger = logging.getLogger(__name__)

# 數值精度造成 cos 值略超出 [-1, 1] 時的裁切容忍範圍
_COS_CLIP_RANGE = (-1.0, 1.0)
_MIN_VECTOR_NORM = 1e-6  # 視為退化（零長度）向量的門檻


@dataclass(frozen=True, slots=True)
class JointTriplet:
    """定義一組「頂點關節 + 兩側相鄰關節」用於角度計算。"""

    proximal: str  # 近端關節名稱，如 "left_hip"
    vertex: str  # 頂點關節名稱，如 "left_knee"
    distal: str  # 遠端關節名稱，如 "left_ankle"


# 第一階段擷取的下肢關節可組成的標準三點角度定義
KNEE_TRIPLETS: dict[str, JointTriplet] = {
    "left": JointTriplet("left_hip", "left_knee", "left_ankle"),
    "right": JointTriplet("right_hip", "right_knee", "right_ankle"),
}


def compute_joint_angle_deg(
    proximal: JointPoint, vertex: JointPoint, distal: JointPoint
) -> Optional[float]:
    """
    計算頂點關節的夾角（單位：度）。

    Args:
        proximal: 近端關節座標（如髖）。
        vertex: 頂點關節座標（如膝）。
        distal: 遠端關節座標（如踝）。

    Returns:
        夾角（0-180 度）；若任一向量退化為零長度（座標重合），回傳 None。
    """
    vec_ba = np.array([proximal.x - vertex.x, proximal.y - vertex.y])
    vec_bc = np.array([distal.x - vertex.x, distal.y - vertex.y])

    norm_ba = float(np.linalg.norm(vec_ba))
    norm_bc = float(np.linalg.norm(vec_bc))

    if norm_ba < _MIN_VECTOR_NORM or norm_bc < _MIN_VECTOR_NORM:
        logger.debug("關節座標退化（向量長度趨近於零），無法計算角度")
        return None

    cos_theta = np.dot(vec_ba, vec_bc) / (norm_ba * norm_bc)
    cos_theta = float(np.clip(cos_theta, *_COS_CLIP_RANGE))
    return float(np.degrees(np.arccos(cos_theta)))


def compute_angle_sequence(
    frames: list[JointFrame], triplet: JointTriplet
) -> list[Optional[float]]:
    """
    對一序列影格計算指定三點關節的角度時間序列。

    任一影格缺少所需的三個關節點時（信心不足被第一階段過濾掉），
    該影格回傳 None，由下游濾波模組決定如何處理缺值，而非直接中斷整條序列。

    Args:
        frames: 第一階段輸出的關節影格序列。
        triplet: 角度定義（近端、頂點、遠端關節名稱）。

    Returns:
        與輸入等長的角度序列（單位：度），缺值處為 None。
    """
    angles: list[Optional[float]] = []
    for frame in frames:
        proximal = frame.joints.get(triplet.proximal)
        vertex = frame.joints.get(triplet.vertex)
        distal = frame.joints.get(triplet.distal)

        if proximal is None or vertex is None or distal is None:
            angles.append(None)
            continue

        angles.append(compute_joint_angle_deg(proximal, vertex, distal))

    return angles
