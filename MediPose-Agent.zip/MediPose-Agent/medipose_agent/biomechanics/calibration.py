"""
空間校正模組（像素 → 公分）。

利用畫面中已知實際尺寸的參考物（預設 A4 紙：21.0 x 29.7 公分）四個角點，
計算 Homography 轉換矩陣，將像素座標映射為以參考物左上角為原點的
平面實際距離（公分）。

【目前使用範圍說明】本模組目前不被 ROM / Jerk Score / Symmetry Index
等角度類指標呼叫，因為角度計算與絕對尺度無關。本模組是為未來「位移量」
類指標（如步態跨距、軌跡總長）預留的基礎建設。

【已知限制】Homography 為平面轉換，僅在「待測點與參考物位於同一平面」
時準確；若關節運動有明顯前後（朝向/遠離鏡頭）位移，超出該平面的距離
量測仍會失真，此限制與視角補償模組處理的問題本質相同，目前未整合。
"""
from __future__ import annotations

import logging
from typing import NamedTuple, Optional

import numpy as np

from ..config import CalibrationConfig

logger = logging.getLogger(__name__)

_EXPECTED_CORNER_COUNT = 4


class PixelPoint(NamedTuple):
    x: float
    y: float


class CmPoint(NamedTuple):
    x: float
    y: float


def compute_homography(
    corner_points_px: list[PixelPoint], config: Optional[CalibrationConfig] = None
) -> np.ndarray:
    """
    依參考物四角點的像素座標，計算像素→公分的 Homography 矩陣。

    Args:
        corner_points_px: 參考物四角點像素座標，順序須為
            [左上, 右上, 右下, 左下]（順時針）。
        config: 校正設定（參考物實際尺寸），預設使用 A4 紙尺寸。

    Returns:
        3x3 Homography 矩陣，可配合 `pixel_to_cm` 使用。

    Raises:
        ValueError: 角點數量不為 4，或角點座標共線（無法構成有效四邊形）時拋出。
    """
    if len(corner_points_px) != _EXPECTED_CORNER_COUNT:
        raise ValueError(
            f"需要剛好 {_EXPECTED_CORNER_COUNT} 個角點座標，"
            f"收到 {len(corner_points_px)} 個"
        )

    cfg = config or CalibrationConfig()

    src = np.array(corner_points_px, dtype=np.float32)
    dst = np.array(
        [
            [0.0, 0.0],
            [cfg.reference_width_cm, 0.0],
            [cfg.reference_width_cm, cfg.reference_height_cm],
            [0.0, cfg.reference_height_cm],
        ],
        dtype=np.float32,
    )

    import cv2  # 延遲匯入，避免無相關需求的模組強制相依 cv2

    homography, status = cv2.findHomography(src, dst, method=0)
    if homography is None or status is None or not np.all(status):
        raise ValueError("無法計算 Homography，請確認四個角點不共線且座標正確")

    return homography


def pixel_to_cm(point_px: PixelPoint, homography: np.ndarray) -> CmPoint:
    """
    將單一像素座標依 Homography 矩陣轉換為公分座標（相對參考物左上角原點）。

    Args:
        point_px: 待轉換的像素座標。
        homography: `compute_homography` 取得的轉換矩陣。

    Returns:
        轉換後的平面座標（公分）。
    """
    homogeneous = np.array([point_px.x, point_px.y, 1.0])
    transformed = homography @ homogeneous
    transformed /= transformed[2]
    return CmPoint(float(transformed[0]), float(transformed[1]))
