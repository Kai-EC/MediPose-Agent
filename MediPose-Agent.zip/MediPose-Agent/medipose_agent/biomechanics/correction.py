"""
視角自適應幾何補償模組（Viewing-Angle Adaptive Correction）。

【設計動機】
本系統允許相機自由擺放，單目 2D 姿態估計在非標準側面視角下，
量測到的關節夾角會因「肢段所在運動平面」相對「相機成像平面」存在
偏轉角 φ 而產生系統性失真。

【方法與已知限制（請務必一併閱讀，避免誤用本模組的結論）】
本模組採用「骨段透視縮短比例」估算 φ：假設使用者於錄影初期（校正幀）
大致面對鏡頭，此時量得的骨段投影長度視為基準長度 L_ref（φ≈0）。
後續任一影格，若骨段投影長度縮短為 L'，則：

    cos(φ) ≈ L' / L_ref

此為一階近似，成立前提是肢段運動主要繞「單一垂直軸」旋轉，且該軸
與骨段方向不平行（若肢段本身接近平行於旋轉軸，例如站姿下大腿接近
鉛直，繞鉛直軸旋轉造成的縮短效應會被低估）。本模組無法處理複合式
多軸旋轉，僅能提供「一階修正 + 信賴區間」，不宣稱完全還原真實三維角度。

角度修正同樣採一階近似：假設關節「偏離全伸直角度（180°）的屈曲量」
與肢段所在平面的投影縮短比例近似成反比關係：

    deviation_corrected = deviation_raw / cos(φ)
    theta_corrected = 180° - deviation_corrected

並以修正前後的差值做為信賴區間半寬（修正幅度越大，代表原始量測
越不可靠）。當 φ 超過設定門檻（預設 60°）時，視為不可信，回傳 None
並標記旗標，而非輸出一個看似精確、實際上已無意義的數字。
"""
from __future__ import annotations

import logging
import statistics
from dataclasses import dataclass
from typing import Optional

import numpy as np

from ..config import CorrectionConfig
from ..joint_extractor import JointFrame, JointPoint

logger = logging.getLogger(__name__)

_MIN_COS_PHI = 1e-3  # 避免 1/cos(phi) 在 phi 接近 90 度時發散


@dataclass(frozen=True, slots=True)
class CorrectedAngle:
    """單一影格的補償後角度結果。"""

    theta_raw_deg: float
    theta_corrected_deg: Optional[float]
    phi_deg: Optional[float]
    confidence_margin_deg: Optional[float]
    is_reliable: bool
    dual_segment_disagreement_flag: bool = False


def _segment_length(point_a: JointPoint, point_b: JointPoint) -> float:
    return float(np.hypot(point_a.x - point_b.x, point_a.y - point_b.y))


def estimate_reference_lengths(
    frames: list[JointFrame],
    proximal_name: str,
    vertex_name: str,
    distal_name: str,
    calibration_frame_count: int,
) -> Optional[tuple[float, float]]:
    """
    從序列開頭的校正幀估算近端骨段（proximal-vertex）與遠端骨段
    （vertex-distal）的基準長度，做為後續 φ 估算的參考值。

    Args:
        frames: 完整影格序列。
        proximal_name, vertex_name, distal_name: 三點關節名稱。
        calibration_frame_count: 取前 N 幀計算中位數做為基準長度，
            使用中位數而非平均數以降低個別偵測雜訊幀的影響。

    Returns:
        (近端骨段基準長度, 遠端骨段基準長度)；若校正幀內找不到足夠的
        有效偵測，回傳 None。
    """
    proximal_lengths: list[float] = []
    distal_lengths: list[float] = []

    for frame in frames[:calibration_frame_count]:
        proximal = frame.joints.get(proximal_name)
        vertex = frame.joints.get(vertex_name)
        distal = frame.joints.get(distal_name)

        if proximal and vertex:
            proximal_lengths.append(_segment_length(proximal, vertex))
        if vertex and distal:
            distal_lengths.append(_segment_length(vertex, distal))

    if not proximal_lengths or not distal_lengths:
        logger.warning(
            "校正幀範圍內缺少足夠的有效關節偵測，無法估算骨段基準長度"
        )
        return None

    return statistics.median(proximal_lengths), statistics.median(distal_lengths)


def _estimate_phi_deg(observed_length: float, reference_length: float) -> Optional[float]:
    """依骨段投影縮短比例估算視角偏轉角 φ（度）。"""
    if reference_length <= 0:
        return None
    ratio = float(np.clip(observed_length / reference_length, 0.0, 1.0))
    return float(np.degrees(np.arccos(ratio)))


def correct_frame_angle(
    theta_raw_deg: float,
    proximal: JointPoint,
    vertex: JointPoint,
    distal: JointPoint,
    reference_lengths: tuple[float, float],
    config: Optional[CorrectionConfig] = None,
) -> CorrectedAngle:
    """
    對單一影格的關節角度套用視角自適應補償。

    Args:
        theta_raw_deg: 該影格原始量測角度（度）。
        proximal, vertex, distal: 該影格三個關節點座標。
        reference_lengths: (近端骨段基準長度, 遠端骨段基準長度)，
            由 `estimate_reference_lengths` 取得。
        config: 補償設定，預設使用 CorrectionConfig() 預設值。

    Returns:
        補償後的角度結果，包含信賴區間與可靠性旗標。
    """
    cfg = config or CorrectionConfig()
    ref_proximal_len, ref_distal_len = reference_lengths

    proximal_len = _segment_length(proximal, vertex)
    distal_len = _segment_length(vertex, distal)

    phi_proximal = _estimate_phi_deg(proximal_len, ref_proximal_len)
    phi_distal = _estimate_phi_deg(distal_len, ref_distal_len)

    valid_phis = [p for p in (phi_proximal, phi_distal) if p is not None]
    if not valid_phis:
        return CorrectedAngle(theta_raw_deg, None, None, None, is_reliable=False)

    # 雙骨段獨立估算的 φ 若差異過大，代表「單軸旋轉」假設可能不成立，
    # 誠實標記此情況，而非默默取平均掩蓋掉模型假設失效的訊號。
    disagreement_flag = False
    if phi_proximal is not None and phi_distal is not None:
        if abs(phi_proximal - phi_distal) > cfg.dual_segment_disagreement_deg:
            disagreement_flag = True
            logger.debug(
                "雙骨段 φ 估算差異過大 (proximal=%.1f, distal=%.1f)，"
                "單軸旋轉假設可能不成立",
                phi_proximal, phi_distal,
            )

    phi_deg = statistics.mean(valid_phis)

    if phi_deg > cfg.max_phi_deg:
        return CorrectedAngle(
            theta_raw_deg, None, phi_deg, None,
            is_reliable=False, dual_segment_disagreement_flag=disagreement_flag,
        )

    cos_phi = float(np.cos(np.radians(phi_deg)))
    if cos_phi < _MIN_COS_PHI:
        return CorrectedAngle(
            theta_raw_deg, None, phi_deg, None,
            is_reliable=False, dual_segment_disagreement_flag=disagreement_flag,
        )

    deviation_raw = 180.0 - theta_raw_deg
    deviation_corrected = deviation_raw / cos_phi
    theta_corrected = float(np.clip(180.0 - deviation_corrected, 0.0, 180.0))
    margin = abs(deviation_corrected - deviation_raw)

    return CorrectedAngle(
        theta_raw_deg=theta_raw_deg,
        theta_corrected_deg=theta_corrected,
        phi_deg=phi_deg,
        confidence_margin_deg=margin,
        is_reliable=True,
        dual_segment_disagreement_flag=disagreement_flag,
    )
