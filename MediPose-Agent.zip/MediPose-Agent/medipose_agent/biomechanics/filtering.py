"""
數位訊號處理模組：二階低通巴特沃斯濾波器。

對角度時間序列進行雙向零相位濾波（`scipy.signal.filtfilt`），消除視覺
姿態估計常見的高頻像素抖動，且不會造成相位延遲。濾波前需先處理缺值
（None），採線性插補（短缺口）或斷段處理（長缺口）。
"""
from __future__ import annotations

import logging
from typing import Optional

import numpy as np
from scipy.signal import butter, filtfilt

from ..config import FilterConfig

logger = logging.getLogger(__name__)


def interpolate_missing_values(
    sequence: list[Optional[float]], max_gap: int
) -> list[Optional[float]]:
    """
    對序列中的缺值（None）做線性插補，超過 max_gap 的連續缺口不插補。

    Args:
        sequence: 含 None 缺值的數值序列。
        max_gap: 允許插補的最大連續缺值長度（影格數）。

    Returns:
        插補後的序列；無法插補的長缺口位置維持 None。
    """
    values = list(sequence)
    n = len(values)
    i = 0
    while i < n:
        if values[i] is not None:
            i += 1
            continue

        gap_start = i
        while i < n and values[i] is None:
            i += 1
        gap_end = i  # 缺值範圍為 [gap_start, gap_end)
        gap_length = gap_end - gap_start

        has_left = gap_start > 0 and values[gap_start - 1] is not None
        has_right = gap_end < n and values[gap_end] is not None

        if gap_length > max_gap or not (has_left and has_right):
            logger.debug(
                "缺值區間 [%d, %d) 長度=%d 超過上限或位於序列邊界，不插補",
                gap_start, gap_end, gap_length,
            )
            continue

        left_value = values[gap_start - 1]
        right_value = values[gap_end]
        assert left_value is not None and right_value is not None
        interpolated = np.linspace(left_value, right_value, gap_length + 2)[1:-1]
        for offset, value in enumerate(interpolated):
            values[gap_start + offset] = float(value)

    return values


def butterworth_lowpass_filter(
    sequence: list[Optional[float]], config: Optional[FilterConfig] = None
) -> list[Optional[float]]:
    """
    對角度序列套用二階低通巴特沃斯濾波器（零相位雙向濾波）。

    序列中無法插補的缺值會將完整序列切割為多個連續有效片段，
    分別獨立濾波後再依原始位置拼回，避免缺值跨段汙染濾波結果。

    Args:
        sequence: 角度時間序列（可含 None 缺值）。
        config: 濾波器設定，預設使用 FilterConfig() 預設值。

    Returns:
        濾波後序列，長度與輸入相同；無法濾波的片段（過短）維持原值。

    Raises:
        ValueError: cutoff_hz 未小於奈奎斯特頻率（sampling_hz / 2）時拋出。
    """
    cfg = config or FilterConfig()
    nyquist = cfg.sampling_hz / 2.0
    normalized_cutoff = cfg.cutoff_hz / nyquist
    if not 0.0 < normalized_cutoff < 1.0:
        raise ValueError(
            f"cutoff_hz ({cfg.cutoff_hz}) 必須小於奈奎斯特頻率 ({nyquist})，"
            f"請確認 sampling_hz 設定正確"
        )

    interpolated = interpolate_missing_values(sequence, cfg.max_interpolation_gap)

    b, a = butter(cfg.order, normalized_cutoff, btype="low", analog=False)

    # filtfilt 要求輸入長度至少為 padlen 的數倍，片段過短時無法濾波，原值保留
    min_required_length = 3 * (max(len(a), len(b)) - 1) + 1

    result: list[Optional[float]] = list(interpolated)
    n = len(result)
    i = 0
    while i < n:
        if result[i] is None:
            i += 1
            continue

        seg_start = i
        while i < n and result[i] is not None:
            i += 1
        seg_end = i  # 有效片段範圍 [seg_start, seg_end)

        segment = np.array(result[seg_start:seg_end], dtype=float)
        if len(segment) < min_required_length:
            logger.debug(
                "片段 [%d, %d) 長度=%d 小於濾波最小需求長度=%d，跳過濾波",
                seg_start, seg_end, len(segment), min_required_length,
            )
            continue

        filtered_segment = filtfilt(b, a, segment)
        result[seg_start:seg_end] = filtered_segment.tolist()

    return result
