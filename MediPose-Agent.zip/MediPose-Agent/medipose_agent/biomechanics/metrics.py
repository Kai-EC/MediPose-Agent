"""
特徵聚合器模組（Feature Aggregator）。

由濾波後的關節角度時間序列計算四項臨床力學指標：

1. Max ROM（最大活動度）：序列峰對峰值。
2. Jerk Score（運動平滑度）：採用 Log Dimensionless Jerk（LDLJ），
   公式參考 Hogan & Sternad (2009), "Sensitivity of smoothness measures
   to movement duration, amplitude, and arrests"，速度型定義：

       LDLJ = -ln( (duration^3 / peak_velocity^2) * ∫ jerk(t)^2 dt )

   數值越接近 0（越不負）代表動作越平滑；經對數無因次化處理，
   不受動作幅度與速度差異影響，可跨次測量比較。
3. Symmetry Index（左右對稱度）：採用 Robinson et al. (1987) 公式：

       SI(%) = (X_L - X_R) / (0.5 * (X_L + X_R)) * 100

4. 代償觸發次數：規則式偵測，非學習模型。目前僅能依「角速度突波」
   與「左右對稱度超標」做簡化判斷，無法偵測軀幹代償（需上半身關節，
   現階段資料未涵蓋），此為已知限制。
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Optional

import numpy as np

from ..config import MetricsConfig

logger = logging.getLogger(__name__)

_MIN_VALID_SAMPLES = 5  # 計算 Jerk Score 所需的最少有效樣本數
_EPSILON = 1e-9


def _extract_valid_segment(sequence: list[Optional[float]]) -> np.ndarray:
    """取出序列中最長的連續有效（非 None）片段。"""
    best_start, best_len = 0, 0
    cur_start, cur_len = 0, 0

    for i, value in enumerate(sequence):
        if value is not None:
            if cur_len == 0:
                cur_start = i
            cur_len += 1
            if cur_len > best_len:
                best_start, best_len = cur_start, cur_len
        else:
            cur_len = 0

    if best_len == 0:
        return np.array([])
    return np.array(sequence[best_start : best_start + best_len], dtype=float)


def compute_max_rom(sequence: list[Optional[float]]) -> Optional[float]:
    """計算最大活動度（峰對峰值，單位：度）。"""
    valid = [v for v in sequence if v is not None]
    if not valid:
        return None
    return float(max(valid) - min(valid))


def compute_log_dimensionless_jerk(
    sequence: list[Optional[float]], sampling_hz: float
) -> Optional[float]:
    """
    計算速度型 Log Dimensionless Jerk（LDLJ）平滑度指標。

    僅使用序列中最長的連續有效片段計算（缺值片段無法做有意義的微分）。

    Args:
        sequence: 濾波後角度序列（度），可含 None。
        sampling_hz: 取樣頻率（Hz）。

    Returns:
        LDLJ 分數；資料不足或動作幅度趨近於零（無有效運動）時回傳 None。
    """
    segment = _extract_valid_segment(sequence)
    if len(segment) < _MIN_VALID_SAMPLES:
        logger.warning(
            "有效連續樣本數 (%d) 不足以計算 Jerk Score（需至少 %d）",
            len(segment), _MIN_VALID_SAMPLES,
        )
        return None

    dt = 1.0 / sampling_hz
    velocity = np.gradient(segment, dt)
    acceleration = np.gradient(velocity, dt)
    jerk = np.gradient(acceleration, dt)

    duration = (len(segment) - 1) * dt
    peak_velocity = float(np.max(np.abs(velocity)))

    if peak_velocity < _EPSILON:
        logger.warning("偵測到的角速度趨近於零（動作幅度過小），無法計算有意義的 Jerk Score")
        return None

    # 手刻梯形積分公式（避免依賴 numpy 版本相關的 trapz/trapezoid 函式名稱差異）：
    # integral ≈ dt * (sum(y) - 0.5*(y[0] + y[-1]))
    jerk_squared = jerk**2
    jerk_integral = float(dt * (np.sum(jerk_squared) - 0.5 * (jerk_squared[0] + jerk_squared[-1])))
    dimensionless_jerk = (duration**3 / peak_velocity**2) * jerk_integral

    if dimensionless_jerk <= 0:
        return None

    return float(-np.log(dimensionless_jerk))


def compute_symmetry_index(value_left: float, value_right: float) -> Optional[float]:
    """
    計算 Robinson 對稱指數（%）。

    Args:
        value_left: 左側量測值（如左膝 Max ROM）。
        value_right: 右側量測值。

    Returns:
        對稱指數（%），正值代表左側較大，負值代表右側較大；
        若左右量測值皆趨近於零，回傳 None（無意義的除以零情況）。
    """
    denominator = 0.5 * (value_left + value_right)
    if abs(denominator) < _EPSILON:
        return None
    return float((value_left - value_right) / denominator * 100.0)


def detect_angular_velocity_anomalies(
    sequence: list[Optional[float]], sampling_hz: float, config: Optional[MetricsConfig] = None
) -> int:
    """
    計算角速度超過異常門檻的影格數，做為代償/失控動作的簡易代理指標。

    Args:
        sequence: 濾波後角度序列（度），可含 None。
        sampling_hz: 取樣頻率（Hz）。
        config: 特徵聚合設定，預設使用 MetricsConfig() 預設值。

    Returns:
        角速度超標的影格數。
    """
    cfg = config or MetricsConfig()
    segment = _extract_valid_segment(sequence)
    if len(segment) < 2:
        return 0

    dt = 1.0 / sampling_hz
    velocity = np.gradient(segment, dt)
    return int(np.sum(np.abs(velocity) > cfg.angular_velocity_anomaly_deg_per_sec))


@dataclass(frozen=True, slots=True)
class SessionMetrics:
    """單次復健 session 的彙整力學指標。"""

    max_rom_left_deg: Optional[float]
    max_rom_right_deg: Optional[float]
    jerk_score_left: Optional[float]
    jerk_score_right: Optional[float]
    symmetry_index_pct: Optional[float]
    velocity_anomaly_count_left: int
    velocity_anomaly_count_right: int
    compensation_suspected: bool


def aggregate_session_metrics(
    left_sequence: list[Optional[float]],
    right_sequence: list[Optional[float]],
    sampling_hz: float,
    config: Optional[MetricsConfig] = None,
) -> SessionMetrics:
    """
    彙整左右膝關節角度序列為完整的 session 力學指標報告。

    Args:
        left_sequence: 左膝濾波後角度序列。
        right_sequence: 右膝濾波後角度序列。
        sampling_hz: 取樣頻率（Hz）。
        config: 特徵聚合設定，預設使用 MetricsConfig() 預設值。

    Returns:
        彙整後的 SessionMetrics。
    """
    cfg = config or MetricsConfig()

    max_rom_left = compute_max_rom(left_sequence)
    max_rom_right = compute_max_rom(right_sequence)

    jerk_left = compute_log_dimensionless_jerk(left_sequence, sampling_hz)
    jerk_right = compute_log_dimensionless_jerk(right_sequence, sampling_hz)

    symmetry_index = None
    if max_rom_left is not None and max_rom_right is not None:
        symmetry_index = compute_symmetry_index(max_rom_left, max_rom_right)

    anomaly_left = detect_angular_velocity_anomalies(left_sequence, sampling_hz, cfg)
    anomaly_right = detect_angular_velocity_anomalies(right_sequence, sampling_hz, cfg)

    compensation_suspected = (anomaly_left > 0) or (anomaly_right > 0)
    if symmetry_index is not None and abs(symmetry_index) > cfg.symmetry_index_anomaly_pct:
        compensation_suspected = True

    return SessionMetrics(
        max_rom_left_deg=max_rom_left,
        max_rom_right_deg=max_rom_right,
        jerk_score_left=jerk_left,
        jerk_score_right=jerk_right,
        symmetry_index_pct=symmetry_index,
        velocity_anomaly_count_left=anomaly_left,
        velocity_anomaly_count_right=anomaly_right,
        compensation_suspected=compensation_suspected,
    )
