"""
影像擷取模組。

採用生產者-消費者模式進行非阻塞式影像讀取：背景執行緒持續從 Webcam
或影片檔案讀取影格並放入有界佇列，主執行緒透過 `read()` 取得最新影格，
避免 I/O 等待拖慢姿態推論迴圈，並以佇列上限防止記憶體無限增長。
"""
from __future__ import annotations

import logging
import queue
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Union

import cv2
import numpy as np

from .config import CaptureConfig

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class CapturedFrame:
    """單一影格資料容器。"""

    frame_id: int
    timestamp: float
    image: np.ndarray


class VideoStreamReader:
    """
    非同步影像串流讀取器。

    支援 Webcam（整數索引）與影片檔案（路徑）兩種來源，於獨立執行緒中
    持續讀取影格並放入執行緒安全佇列，主執行緒透過 `read()` 非阻塞取得
    最新影格。建議透過 context manager（`with`）使用以確保資源正確釋放。
    """

    def __init__(
        self,
        source: Union[int, str, Path],
        config: Optional[CaptureConfig] = None,
    ) -> None:
        """
        Args:
            source: Webcam 裝置索引（如 0）或影片檔案路徑。
            config: 擷取設定，預設使用 CaptureConfig() 預設值。

        Raises:
            ValueError: 來源為負數索引，或檔案路徑不存在時拋出。
        """
        self._config = config or CaptureConfig()
        self._source = self._validate_source(source)

        self._capture: Optional[cv2.VideoCapture] = None
        self._frame_queue: "queue.Queue[CapturedFrame]" = queue.Queue(
            maxsize=self._config.queue_max_size
        )
        self._stop_event = threading.Event()
        self._reader_thread: Optional[threading.Thread] = None

        self._frame_counter = 0
        self._dropped_frame_count = 0

    @staticmethod
    def _validate_source(source: Union[int, str, Path]) -> Union[int, str]:
        """驗證輸入來源的合法性，並正規化為 cv2.VideoCapture 可接受的型別。"""
        if isinstance(source, int):
            if source < 0:
                raise ValueError(f"Webcam 索引不可為負數，收到: {source}")
            return source

        path = Path(source)
        if not path.exists():
            raise ValueError(f"找不到影片檔案: {path}")
        return str(path)

    def __enter__(self) -> "VideoStreamReader":
        self.start()
        return self

    def __exit__(self, exc_type: object, exc_val: object, exc_tb: object) -> None:
        self.stop()

    def start(self) -> None:
        """開啟擷取裝置並啟動背景讀取執行緒。

        Raises:
            RuntimeError: 裝置無法開啟時拋出。
        """
        self._capture = cv2.VideoCapture(self._source)
        if not self._capture.isOpened():
            raise RuntimeError(f"無法開啟影像來源: {self._source}")

        self._capture.set(cv2.CAP_PROP_FPS, self._config.target_fps)

        self._stop_event.clear()
        self._reader_thread = threading.Thread(
            target=self._read_loop, daemon=True, name="VideoStreamReader"
        )
        self._reader_thread.start()
        logger.info("影像串流已啟動: source=%s", self._source)

    def stop(self) -> None:
        """停止讀取執行緒並釋放裝置資源。"""
        self._stop_event.set()
        if self._reader_thread is not None:
            self._reader_thread.join(timeout=2.0)
        if self._capture is not None:
            self._capture.release()
        logger.info(
            "影像串流已停止: 總讀取影格數=%d, 丟棄影格數=%d",
            self._frame_counter,
            self._dropped_frame_count,
        )

    def _read_loop(self) -> None:
        """背景執行緒主迴圈：持續讀取影格並放入佇列。"""
        assert self._capture is not None
        frame_interval = 1.0 / self._config.target_fps
        next_frame_time = time.monotonic()

        while not self._stop_event.is_set():
            ok, image = self._capture.read()
            if not ok:
                logger.warning("讀取影格失敗，串流可能已結束或中斷")
                break

            captured = CapturedFrame(
                frame_id=self._frame_counter,
                timestamp=time.monotonic(),
                image=image,
            )
            self._frame_counter += 1

            try:
                self._frame_queue.put_nowait(captured)
            except queue.Full:
                # 佇列已滿時，丟棄最舊影格以保持即時性（避免延遲累積）
                try:
                    self._frame_queue.get_nowait()
                except queue.Empty:
                    pass
                self._frame_queue.put_nowait(captured)
                self._dropped_frame_count += 1
                logger.debug("佇列已滿，丟棄最舊影格以維持即時性")

            # 簡易節流，避免讀取速度超過目標 FPS 造成佇列堆積
            next_frame_time += frame_interval
            sleep_duration = next_frame_time - time.monotonic()
            if sleep_duration > 0:
                time.sleep(sleep_duration)

    def read(self, timeout: float = 1.0) -> Optional[CapturedFrame]:
        """
        從佇列取出最新影格（附逾時保護）。

        Args:
            timeout: 等待影格的最長秒數。

        Returns:
            取得的影格；若逾時則回傳 None。
        """
        try:
            return self._frame_queue.get(timeout=timeout)
        except queue.Empty:
            return None

    @property
    def is_running(self) -> bool:
        """背景讀取執行緒是否仍在運作中。"""
        return self._reader_thread is not None and self._reader_thread.is_alive()

    @property
    def stats(self) -> dict[str, int]:
        """目前擷取狀態統計，供品質監控與除錯使用。"""
        return {
            "total_frames": self._frame_counter,
            "dropped_frames": self._dropped_frame_count,
            "queue_size": self._frame_queue.qsize(),
        }
