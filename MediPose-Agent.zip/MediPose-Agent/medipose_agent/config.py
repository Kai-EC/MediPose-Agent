"""
MediPose-Agent 系統配置模組。

集中管理所有可調參數（模型路徑、信心門檻、緩衝區大小等），
避免在各功能模組中散落 Magic Number 與 Hardcoded Path，
便於後續階段（力學分析、LLM、前端）統一讀取同一份設定。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Final

# ---------------------------------------------------------------------------
# COCO 17 關鍵點索引對照表（YOLOv11-Pose 沿用 COCO 標準關鍵點順序）
# ---------------------------------------------------------------------------
COCO_KEYPOINT_NAMES: Final[tuple[str, ...]] = (
    "nose", "left_eye", "right_eye", "left_ear", "right_ear",
    "left_shoulder", "right_shoulder", "left_elbow", "right_elbow",
    "left_wrist", "right_wrist", "left_hip", "right_hip",
    "left_knee", "right_knee", "left_ankle", "right_ankle",
)

# 第一階段僅需求下肢核心關節：左右髖、左右膝、左右踝
LOWER_BODY_KEYPOINTS: Final[dict[str, int]] = {
    "left_hip": 11,
    "right_hip": 12,
    "left_knee": 13,
    "right_knee": 14,
    "left_ankle": 15,
    "right_ankle": 16,
}


@dataclass(frozen=True, slots=True)
class CaptureConfig:
    """影像擷取相關設定。"""

    target_fps: int = 30
    queue_max_size: int = 64  # 緩衝佇列上限，避免記憶體無限增長
    reconnect_retry_limit: int = 5
    reconnect_delay_sec: float = 1.0


@dataclass(frozen=True, slots=True)
class PoseModelConfig:
    """YOLOv11-Pose 模型相關設定。"""

    model_path: Path = Path("models/yolo11m-pose.pt")
    input_size: int = 640
    confidence_threshold: float = 0.5  # 關鍵點信心門檻，低於此值視為不可信
    device: str = "auto"  # "auto" | "cuda" | "cpu"


@dataclass(frozen=True, slots=True)
class BufferConfig:
    """關節資料緩衝區設定。"""

    max_frames: int = 9000  # 30FPS * 300秒 = 5分鐘份量，避免記憶體無限增長
    export_dir: Path = Path("output/joint_sequences")


@dataclass(frozen=True, slots=True)
class FilterConfig:
    """巴特沃斯低通濾波器設定。"""

    cutoff_hz: float = 6.0
    order: int = 2
    sampling_hz: float = 30.0  # 須與 CaptureConfig.target_fps 一致
    max_interpolation_gap: int = 5  # 超過此影格數的連續缺值不插補，視為斷段


@dataclass(frozen=True, slots=True)
class CorrectionConfig:
    """視角自適應幾何補償設定。"""

    calibration_frame_count: int = 15  # 取前 N 幀估算骨段校正基準長度
    max_phi_deg: float = 60.0  # 超過此偏轉角，量測視為不可信
    dual_segment_disagreement_deg: float = 20.0  # 左右骨段估出的 φ 差異超過此值即標記異常


@dataclass(frozen=True, slots=True)
class MetricsConfig:
    """特徵聚合器設定。"""

    angular_velocity_anomaly_deg_per_sec: float = 300.0  # 角速度超標視為代償徵兆
    symmetry_index_anomaly_pct: float = 15.0  # 對稱指數超標視為代償徵兆


@dataclass(frozen=True, slots=True)
class CalibrationConfig:
    """像素-公分空間校正設定（A4 紙）。"""

    reference_width_cm: float = 21.0
    reference_height_cm: float = 29.7


@dataclass(frozen=True, slots=True)
class ChunkingConfig:
    """文件切片設定。"""

    chunk_size_chars: int = 500  # 約對應報告書規劃的 500 tokens（中文以字元數近似）
    chunk_overlap_chars: int = 50
    sentence_boundary_chars: tuple[str, ...] = ("。", "！", "？", "\n")


@dataclass(frozen=True, slots=True)
class EmbeddingConfig:
    """文字向量化設定。"""

    backend: str = "tfidf"  # "tfidf" | "sentence_transformer"
    model_name: str = "BAAI/bge-small-zh-v1.5"  # backend="sentence_transformer" 時使用
    max_features: int = 4096  # backend="tfidf" 時使用


@dataclass(frozen=True, slots=True)
class RetrievalConfig:
    """RAG 檢索設定。"""

    top_k: int = 3
    min_similarity: float = 0.05  # 低於此相似度的片段不納入檢索結果


@dataclass(frozen=True, slots=True)
class LLMConfig:
    """LLM 推論設定。"""

    backend: str = "ollama"  # "ollama" | "mock"
    model_name: str = "llama3-taiwan-8b-instruct"
    ollama_host: str = "http://localhost:11434"
    temperature: float = 0.2  # 醫療報告生成偏好低隨機性，求穩定可重現
    max_tokens: int = 1024
    request_timeout_sec: float = 60.0


@dataclass(frozen=True, slots=True)
class CitationConfig:
    """引用可追溯性驗證設定。"""

    citation_pattern: str = r"\[來源[:：]\s*([\w\-]+)\]"
    require_citation_for_clinical_claims: bool = True


@dataclass(frozen=True, slots=True)
class AppConfig:
    """應用程式總體設定容器。"""

    capture: CaptureConfig = field(default_factory=CaptureConfig)
    pose_model: PoseModelConfig = field(default_factory=PoseModelConfig)
    buffer: BufferConfig = field(default_factory=BufferConfig)
    filtering: FilterConfig = field(default_factory=FilterConfig)
    correction: CorrectionConfig = field(default_factory=CorrectionConfig)
    metrics: MetricsConfig = field(default_factory=MetricsConfig)
    calibration: CalibrationConfig = field(default_factory=CalibrationConfig)
    chunking: ChunkingConfig = field(default_factory=ChunkingConfig)
    embedding: EmbeddingConfig = field(default_factory=EmbeddingConfig)
    retrieval: RetrievalConfig = field(default_factory=RetrievalConfig)
    llm: LLMConfig = field(default_factory=LLMConfig)
    citation: CitationConfig = field(default_factory=CitationConfig)
    log_level: str = "INFO"


DEFAULT_CONFIG: Final[AppConfig] = AppConfig()
