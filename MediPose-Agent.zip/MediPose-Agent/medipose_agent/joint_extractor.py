"""
下肢關節座標提取模組。

從 YOLO 姿態估計結果中過濾出復健分析所需的下肢核心關節（左右髖、
左右膝、左右踝），依信心門檻篩選有效偵測，並輸出結構化資料，
供第二階段生物力學計算模組使用。
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Optional

from .config import LOWER_BODY_KEYPOINTS

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class JointPoint:
    """單一關節點座標與信心值。"""

    x: float
    y: float
    confidence: float


@dataclass(slots=True)
class JointFrame:
    """單一影格的下肢關節結構化資料。"""

    frame_id: int
    timestamp: float
    joints: dict[str, JointPoint] = field(default_factory=dict)
    person_detected: bool = False
    multi_person_warning: bool = False

    def to_dict(self) -> dict[str, Any]:
        """轉換為可序列化為 JSON 的字典格式。"""
        return {
            "frame_id": self.frame_id,
            "timestamp": self.timestamp,
            "person_detected": self.person_detected,
            "multi_person_warning": self.multi_person_warning,
            "joints": {
                name: [point.x, point.y, point.confidence]
                for name, point in self.joints.items()
            },
        }


class LowerBodyJointExtractor:
    """從 YOLO 姿態估計結果提取下肢核心關節座標。"""

    def __init__(self, confidence_threshold: float = 0.5) -> None:
        """
        Args:
            confidence_threshold: 關鍵點信心門檻，低於此值的關節點視為不可信而捨棄。

        Raises:
            ValueError: 門檻值不在 0.0-1.0 範圍內時拋出。
        """
        if not 0.0 <= confidence_threshold <= 1.0:
            raise ValueError(
                f"confidence_threshold 必須介於 0.0-1.0，收到: {confidence_threshold}"
            )
        self._confidence_threshold = confidence_threshold

    def extract(self, frame_id: int, timestamp: float, yolo_result: Any) -> JointFrame:
        """
        從單一影格的 YOLO 推論結果提取下肢關節資料。

        若偵測到多人，僅取關鍵點平均信心值最高者作為主要分析對象
        （假設居家場景以單一患者為主），並標記 multi_person_warning
        旗標，供上層應用判斷是否需提示使用者排除他人入鏡。

        Args:
            frame_id: 影格編號。
            timestamp: 影格擷取時間戳記。
            yolo_result: ultralytics Results 物件，需具備 `.keypoints.xy`
                與 `.keypoints.conf` 屬性（皆為可呼叫 `.cpu().numpy()` 的張量）。

        Returns:
            結構化的下肢關節資料；若未偵測到人物，回傳 joints 為空的 JointFrame。
        """
        joint_frame = JointFrame(frame_id=frame_id, timestamp=timestamp)

        keypoints = getattr(yolo_result, "keypoints", None)
        if keypoints is None or keypoints.conf is None or len(keypoints.conf) == 0:
            logger.debug("影格 %d 未偵測到任何人物", frame_id)
            return joint_frame

        num_persons = len(keypoints.conf)
        if num_persons > 1:
            joint_frame.multi_person_warning = True
            logger.warning(
                "影格 %d 偵測到 %d 人，僅採用信心分數最高者，"
                "建議於前端提示使用者確保畫面中僅有單一患者",
                frame_id, num_persons,
            )

        target_idx = self._select_primary_person(keypoints.conf)
        if target_idx is None:
            return joint_frame

        xy = keypoints.xy[target_idx].cpu().numpy()  # shape: (17, 2)
        conf = keypoints.conf[target_idx].cpu().numpy()  # shape: (17,)

        joint_frame.person_detected = True
        for joint_name, kp_index in LOWER_BODY_KEYPOINTS.items():
            point_conf = float(conf[kp_index])
            if point_conf < self._confidence_threshold:
                logger.debug(
                    "影格 %d 關節 %s 信心值過低 (%.2f < %.2f)，標記為不可信並捨棄",
                    frame_id, joint_name, point_conf, self._confidence_threshold,
                )
                continue

            joint_frame.joints[joint_name] = JointPoint(
                x=float(xy[kp_index][0]),
                y=float(xy[kp_index][1]),
                confidence=point_conf,
            )

        return joint_frame

    @staticmethod
    def _select_primary_person(conf_tensor: Any) -> Optional[int]:
        """從多個偵測人物中，選出關鍵點平均信心值最高者的索引。"""
        if len(conf_tensor) == 0:
            return None
        mean_confidences = conf_tensor.mean(dim=1)
        return int(mean_confidences.argmax().item())
