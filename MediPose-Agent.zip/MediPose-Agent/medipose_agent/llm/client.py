"""
LLM 推論介面模組。

採用 Protocol 定義統一介面，確保 OllamaClient（正式環境）與
MockLLMClient（測試環境）可無縫替換，上層模組不需感知實際後端。

【測試策略說明】
OllamaClient 需要本機已運行的 Ollama 服務，無法在無服務環境測試。
MockLLMClient 回傳含固定引用標記的確定性文字，供第三階段所有上層邏輯
（Prompt 組裝、引用驗證、報告輸出）的單元測試使用。
"""
from __future__ import annotations

import logging
from typing import Iterator, Protocol, runtime_checkable

from ..config import LLMConfig

logger = logging.getLogger(__name__)


@runtime_checkable
class LLMClient(Protocol):
    """LLM 推論客戶端統一介面。"""

    def generate(self, system_prompt: str, user_prompt: str) -> str:
        """
        執行一次完整推論並回傳完整文字結果。

        Args:
            system_prompt: 角色設定與輸出格式規範（中文）。
            user_prompt: 含力學數據與 RAG 片段的具體查詢（中文）。

        Returns:
            LLM 生成的完整中文回覆文字。
        """
        ...

    def generate_stream(self, system_prompt: str, user_prompt: str) -> Iterator[str]:
        """
        逐字串流推論（供 Gradio 前端即時顯示使用）。

        Yields:
            逐步生成的文字片段。
        """
        ...


class OllamaClient:
    """透過 Ollama HTTP API 呼叫在地 LLM 的客戶端。"""

    def __init__(self, config: LLMConfig | None = None) -> None:
        """
        Args:
            config: LLM 設定，預設使用 LLMConfig() 預設值。

        Raises:
            ImportError: 未安裝 requests 套件時拋出。
        """
        try:
            import requests  # noqa: F401  延遲匯入驗證
        except ImportError as exc:
            raise ImportError(
                "未安裝 requests 套件，請執行: pip install requests"
            ) from exc

        self._config = config or LLMConfig()

    def generate(self, system_prompt: str, user_prompt: str) -> str:
        """
        Raises:
            RuntimeError: Ollama 服務連線失敗或回傳錯誤時拋出。
        """
        import requests

        payload = {
            "model": self._config.model_name,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "stream": False,
            "options": {
                "temperature": self._config.temperature,
                "num_predict": self._config.max_tokens,
            },
        }

        try:
            response = requests.post(
                f"{self._config.ollama_host}/api/chat",
                json=payload,
                timeout=self._config.request_timeout_sec,
            )
            response.raise_for_status()
        except requests.RequestException as exc:
            raise RuntimeError(
                f"Ollama 服務連線失敗（host={self._config.ollama_host}），"
                f"請確認 Ollama 已啟動且模型 '{self._config.model_name}' 已下載: {exc}"
            ) from exc

        data = response.json()
        return str(data["message"]["content"])

    def generate_stream(self, system_prompt: str, user_prompt: str) -> Iterator[str]:
        """
        Raises:
            RuntimeError: Ollama 服務連線失敗時拋出。
        """
        import requests

        payload = {
            "model": self._config.model_name,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "stream": True,
            "options": {
                "temperature": self._config.temperature,
                "num_predict": self._config.max_tokens,
            },
        }

        try:
            response = requests.post(
                f"{self._config.ollama_host}/api/chat",
                json=payload,
                timeout=self._config.request_timeout_sec,
                stream=True,
            )
            response.raise_for_status()
        except requests.RequestException as exc:
            raise RuntimeError(
                f"Ollama 串流連線失敗: {exc}"
            ) from exc

        import json
        for line in response.iter_lines():
            if not line:
                continue
            try:
                chunk = json.loads(line)
                if token := chunk.get("message", {}).get("content", ""):
                    yield token
            except json.JSONDecodeError:
                continue


class MockLLMClient:
    """
    測試用確定性 LLM 客戶端。

    回傳含固定引用標記的預設回覆，讓引用驗證、報告組裝等上層邏輯
    可以在無須啟動 Ollama 服務的情況下完整測試。
    """

    MOCK_RESPONSE_TEMPLATE = (
        "根據臨床復健指引，患者左膝最大屈曲角度為 {left_rom:.1f} 度，"
        "右膝為 {right_rom:.1f} 度。[來源: chunk_001]\n\n"
        "左右肢體對稱指數為 {si:.1f}%，{si_interpretation}。[來源: chunk_002]\n\n"
        "建議：{recommendation}[來源: chunk_003]"
    )

    def generate(self, system_prompt: str, user_prompt: str) -> str:
        """回傳含有效引用標記的固定格式回覆（引用 ID 與 Prompt 內容無關）。"""
        logger.debug("MockLLMClient.generate 已被呼叫（測試模式）")
        return self.MOCK_RESPONSE_TEMPLATE.format(
            left_rom=85.0,
            right_rom=82.0,
            si=3.6,
            si_interpretation="左右側差異在臨床可接受範圍內（±15%）",
            recommendation="持續維持現有訓練強度，注意動作平滑度的改善。",
        )

    def generate_stream(self, system_prompt: str, user_prompt: str) -> Iterator[str]:
        """逐字元拆解固定回覆以模擬串流輸出（測試用）。"""
        for char in self.generate(system_prompt, user_prompt):
            yield char


def create_llm_client(config: LLMConfig | None = None) -> LLMClient:
    """
    依設定建立對應的 LLM 客戶端實例。

    Args:
        config: LLM 設定，預設使用 LLMConfig() 預設值。

    Returns:
        對應後端的 LLMClient 實例。

    Raises:
        ValueError: backend 設定值不支援時拋出。
    """
    cfg = config or LLMConfig()
    if cfg.backend == "ollama":
        return OllamaClient(cfg)
    if cfg.backend == "mock":
        return MockLLMClient()
    raise ValueError(f"不支援的 LLM backend: {cfg.backend}")
