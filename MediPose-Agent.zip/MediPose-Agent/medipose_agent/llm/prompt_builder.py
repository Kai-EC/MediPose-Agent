"""
Prompt 組裝模組。

動態將第二階段力學指標（SessionMetrics）與 RAG 檢索結果嵌入
System / User Prompt，控制 LLM 的角色定位、輸出格式與引用規範。

【Prompt 設計原則】
1. System Prompt 明確要求：扮演謹慎的物理治療評估助理，而非診斷醫師
   （呼應 CDSS 定位，避免觸法）；所有臨床推論必須以 [來源: ID] 格式
   引用 RAG 片段；不得自行推斷超出參考資料範圍的臨床結論。
2. User Prompt 以結構化清單呈現量化指標，引導 LLM 做有條理的推論，
   而非讓模型自由發揮導致輸出格式不穩定。
3. 嚴格的引用格式指定（必須是 `[來源: chunk_id]`）使後續的
   `citation_checker.py` 能用正規表達式程式化驗證。
"""
from __future__ import annotations

from ..biomechanics.metrics import SessionMetrics
from ..rag.vector_store import RetrievedChunk

_SYSTEM_PROMPT = """你是一位謹慎、嚴謹的物理治療評估助理。
你的任務是根據患者的量化運動學數據，以及下方提供的臨床參考資料，
協助生成一份結構化的居家復健評估報告（繁體中文）。

【重要規範】
1. 本系統為「決策支援工具（CDSS）」，不取代醫師或物理治療師的臨床判斷。
2. 你的所有臨床推論與建議必須引用下方提供的參考資料。
   引用格式：[來源: chunk_id]，例如：「患者屈曲角度達標。[來源: chunk_001]」
3. 若參考資料中無法支撐某項推論，請明確說明「目前參考資料不足以評估此項目」，
   禁止自行推斷超出資料範圍的臨床結論。
4. 報告應包含：整體評估摘要、左右膝關節個別分析、代償風險說明、復健建議。
5. 使用台灣臨床常用的繁體中文醫學用語。"""


def build_user_prompt(
    metrics: SessionMetrics,
    retrieved_chunks: list[RetrievedChunk],
) -> str:
    """
    組裝含力學指標與 RAG 片段的 User Prompt。

    Args:
        metrics: 第二階段計算出的 session 力學指標。
        retrieved_chunks: RAG 檢索結果，每個片段包含 chunk_id 供 LLM 引用。

    Returns:
        格式化後的 User Prompt 字串。
    """
    metrics_section = _format_metrics_section(metrics)
    references_section = _format_references_section(retrieved_chunks)

    return (
        f"【患者本次復健量化數據】\n{metrics_section}\n\n"
        f"【臨床參考資料（請引用相關片段支撐你的推論）】\n{references_section}\n\n"
        "請依上方數據與參考資料，生成完整的物理治療評估報告。\n"
        "每項臨床推論後必須加上 [來源: chunk_id] 引用標記。"
    )


def _format_metrics_section(metrics: SessionMetrics) -> str:
    """將 SessionMetrics 格式化為可讀的條列式文字。"""

    def _fmt(value: float | None, unit: str = "") -> str:
        return f"{value:.2f}{unit}" if value is not None else "資料不足（信心度不足或遮擋）"

    lines = [
        f"- 左膝最大活動度（Max ROM）：{_fmt(metrics.max_rom_left_deg, '°')}",
        f"- 右膝最大活動度（Max ROM）：{_fmt(metrics.max_rom_right_deg, '°')}",
        f"- 左膝運動平滑度（Jerk Score）：{_fmt(metrics.jerk_score_left)}（越接近 0 越平滑）",
        f"- 右膝運動平滑度（Jerk Score）：{_fmt(metrics.jerk_score_right)}",
        f"- 左右肢體對稱指數（Robinson SI）：{_fmt(metrics.symmetry_index_pct, '%')}",
        f"- 左膝角速度異常影格數：{metrics.velocity_anomaly_count_left}",
        f"- 右膝角速度異常影格數：{metrics.velocity_anomaly_count_right}",
        f"- 疑似代償動作：{'是（請留意相關建議）' if metrics.compensation_suspected else '否'}",
    ]
    return "\n".join(lines)


def _format_references_section(retrieved_chunks: list[RetrievedChunk]) -> str:
    """將 RAG 檢索結果格式化為帶有引用 ID 的參考資料區塊。"""
    if not retrieved_chunks:
        return "（本次查詢無匹配的臨床參考資料）"

    sections = []
    for item in retrieved_chunks:
        chunk_id = item.chunk.chunk_id
        text = item.chunk.text
        similarity = item.similarity
        sections.append(
            f"[{chunk_id}]（相似度：{similarity:.3f}）\n{text}"
        )

    return "\n\n".join(sections)


def build_retrieval_query(metrics: SessionMetrics) -> str:
    """
    依力學指標組成 RAG 檢索查詢句，引導向量檢索找出最相關的臨床指引片段。

    查詢句以「臨床語境」而非「數字」描述問題，因為語意 Embedding
    對概念相似度的捕捉優於精確數值比對。
    """
    parts = ["膝關節活動度復健評估"]

    if metrics.max_rom_left_deg is not None and metrics.max_rom_left_deg < 90:
        parts.append("膝關節屈曲角度不足")
    if metrics.compensation_suspected:
        parts.append("代償動作 異常角速度")
    if metrics.symmetry_index_pct is not None and abs(metrics.symmetry_index_pct) > 15:
        parts.append("左右肢體不對稱 步態補償")
    if metrics.jerk_score_left is not None and metrics.jerk_score_left < -15:
        parts.append("動作不平滑 肌力不足")

    return " ".join(parts)
