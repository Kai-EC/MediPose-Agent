"""
引用可追溯性驗證模組（Citation Traceability Checker）。

【設計動機與學術嚴謹性說明】
原始專案規劃宣稱 RAG 可「完全根除 AI 幻覺」，這在 NLP 領域是已知的
不正確陳述，會在學術面試中造成嚴重扣分。

本模組採取更誠實、更可工程化驗證的替代方案：
    1. 強制要求 LLM 以特定格式（[來源: chunk_id]）標記引用來源
    2. 程式化驗證每個引用的 chunk_id 是否確實存在於本次 RAG 檢索結果中
    3. 計算「可追溯覆蓋率」（有效引用占所有引用的比例）
    4. 將未驗證的句子標記而非靜默隱藏

面試時的正確表述：「本系統不宣稱消除幻覺，而是建立了程式化的
引用可追溯機制，並能量化每份報告的引用有效率，提升臨床可信度」。
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from ..config import CitationConfig


@dataclass(frozen=True, slots=True)
class CitationCheckResult:
    """單份報告的引用驗證結果。"""

    total_citations: int
    valid_citations: int
    invalid_citation_ids: list[str]
    uncited_sentences: list[str]
    traceability_score: float  # 有效引用 / 總引用，範圍 [0, 1]
    annotated_report: str  # 無效引用已標記警示的報告全文


@dataclass
class CitationChecker:
    """對 LLM 生成報告執行引用可追溯性驗證。"""

    config: CitationConfig = field(default_factory=CitationConfig)

    def check(
        self,
        report_text: str,
        valid_chunk_ids: set[str],
    ) -> CitationCheckResult:
        """
        驗證報告中所有引用標記的可追溯性。

        Args:
            report_text: LLM 生成的完整報告文字。
            valid_chunk_ids: 本次 RAG 檢索實際使用的 chunk_id 集合，
                僅這些 ID 視為有效引用來源。

        Returns:
            完整的驗證結果，包含可追溯覆蓋率與標記警示後的報告全文。
        """
        citation_pattern = re.compile(self.config.citation_pattern)
        found_ids = citation_pattern.findall(report_text)

        valid_ids = [cid for cid in found_ids if cid in valid_chunk_ids]
        invalid_ids = [cid for cid in found_ids if cid not in valid_chunk_ids]

        total = len(found_ids)
        valid_count = len(valid_ids)
        score = valid_count / total if total > 0 else 0.0

        annotated = self._annotate_invalid_citations(
            report_text, set(invalid_ids), citation_pattern
        )
        uncited = self._find_uncited_sentences(report_text, citation_pattern)

        return CitationCheckResult(
            total_citations=total,
            valid_citations=valid_count,
            invalid_citation_ids=list(set(invalid_ids)),
            uncited_sentences=uncited,
            traceability_score=score,
            annotated_report=annotated,
        )

    @staticmethod
    def _annotate_invalid_citations(
        text: str, invalid_ids: set[str], pattern: re.Pattern
    ) -> str:
        """
        將報告中無效的引用標記替換為帶有警示符號的版本，
        保留報告可讀性的同時讓使用者知道哪些陳述未經驗證。
        """
        def replace_fn(match: re.Match) -> str:
            chunk_id = match.group(1)
            if chunk_id in invalid_ids:
                return f"[⚠️ 來源未驗證: {chunk_id}]"
            return match.group(0)

        return pattern.sub(replace_fn, text)

    @staticmethod
    def _find_uncited_sentences(text: str, pattern: re.Pattern) -> list[str]:
        """
        找出包含臨床判斷性語彙但缺少引用標記的句子。

        採保守策略：只標記含有特定臨床關鍵詞的句子，避免把
        「患者資料顯示」等事實陳述句也全部列為未引用。
        """
        clinical_keywords = (
            "建議", "應", "須", "需", "不足", "達標", "未達", "風險",
            "代償", "異常", "正常範圍", "顯示", "表示", "指出",
        )
        sentences = re.split(r"[。！？\n]", text)
        uncited = []
        for sentence in sentences:
            stripped = sentence.strip()
            if not stripped:
                continue
            has_keyword = any(kw in stripped for kw in clinical_keywords)
            has_citation = bool(pattern.search(stripped))
            if has_keyword and not has_citation:
                uncited.append(stripped)
        return uncited
