"""
MediPose-Agent 第三階段：在地 LLM + RAG 報告生成主流程。

輸入：第二階段輸出的 session 分析 JSON（含 metrics）
輸出：帶有引用可追溯性驗證結果的完整物理治療評估報告 JSON

使用範例：
    python -m medipose_agent.report_pipeline \\
        --analysis output/joint_sequences/session_xxx_analysis.json \\
        --corpus data/clinical_guidelines.txt
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional

from .biomechanics.metrics import SessionMetrics
from .config import DEFAULT_CONFIG, AppConfig, LLMConfig
from .llm.citation_checker import CitationCheckResult, CitationChecker
from .llm.client import LLMClient, create_llm_client
from .llm.prompt_builder import (
    _SYSTEM_PROMPT,
    build_retrieval_query,
    build_user_prompt,
)
from .rag.document_loader import DocumentChunk, chunk_text
from .rag.retriever import Retriever
from .rag.vector_store import RetrievedChunk

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class ReportResult:
    """完整報告生成結果，含引用驗證與品質指標。"""

    report_text: str
    citation_check: CitationCheckResult
    retrieved_chunks: list[RetrievedChunk]
    retrieval_query: str

    def to_dict(self) -> dict:
        return {
            "report_text": self.report_text,
            "citation_check": asdict(self.citation_check),
            "retrieved_chunks": [
                {
                    "chunk_id": r.chunk.chunk_id,
                    "source": r.chunk.source,
                    "similarity": r.similarity,
                    "text_preview": r.chunk.text[:100] + "…" if len(r.chunk.text) > 100 else r.chunk.text,
                }
                for r in self.retrieved_chunks
            ],
            "retrieval_query": self.retrieval_query,
        }


def build_retriever_from_corpus(
    corpus_path: Path, config: AppConfig
) -> Retriever:
    """
    從臨床指引文本檔建立 RAG 檢索器。

    Args:
        corpus_path: 臨床指引純文字檔路徑（UTF-8 編碼）。
        config: 應用程式設定。

    Returns:
        已建立索引的 Retriever 實例。

    Raises:
        FileNotFoundError: 語料庫檔案不存在時拋出。
        ValueError: 語料庫讀取後為空時拋出。
    """
    if not corpus_path.exists():
        raise FileNotFoundError(f"找不到語料庫檔案: {corpus_path}")

    text = corpus_path.read_text(encoding="utf-8").strip()
    if not text:
        raise ValueError(f"語料庫檔案為空: {corpus_path}")

    chunks: list[DocumentChunk] = chunk_text(
        text, source=corpus_path.stem, config=config.chunking
    )
    logger.info("語料庫已切割為 %d 個片段", len(chunks))

    retriever = Retriever(
        embedding_config=config.embedding,
        retrieval_config=config.retrieval,
    )
    retriever.build_index(chunks)
    return retriever


def generate_report(
    metrics: SessionMetrics,
    retriever: Retriever,
    llm_client: LLMClient,
    config: AppConfig,
) -> ReportResult:
    """
    執行完整的 RAG + LLM 報告生成流程。

    Args:
        metrics: 第二階段計算的 session 力學指標。
        retriever: 已建立索引的 RAG 檢索器。
        llm_client: LLM 推論客戶端。
        config: 應用程式設定。

    Returns:
        帶有引用驗證結果的完整報告。
    """
    query = build_retrieval_query(metrics)
    retrieved = retriever.query(query)
    logger.info("RAG 檢索完成: 查詢='%s', 結果數=%d", query, len(retrieved))

    user_prompt = build_user_prompt(metrics, retrieved)
    report_text = llm_client.generate(_SYSTEM_PROMPT, user_prompt)
    logger.info("LLM 報告生成完成，字元數=%d", len(report_text))

    valid_ids = {r.chunk.chunk_id for r in retrieved}
    checker = CitationChecker(config=config.citation)
    citation_result = checker.check(report_text, valid_ids)

    logger.info(
        "引用驗證完成: 引用總數=%d, 有效=%d, 可追溯率=%.1f%%",
        citation_result.total_citations,
        citation_result.valid_citations,
        citation_result.traceability_score * 100,
    )

    return ReportResult(
        report_text=citation_result.annotated_report,
        citation_check=citation_result,
        retrieved_chunks=retrieved,
        retrieval_query=query,
    )


def _load_metrics_from_analysis_json(path: Path) -> SessionMetrics:
    """從第二階段 pipeline 輸出的 JSON 還原 SessionMetrics。"""
    with path.open(encoding="utf-8") as f:
        data = json.load(f)

    m = data["metrics"]
    return SessionMetrics(
        max_rom_left_deg=m.get("max_rom_left_deg"),
        max_rom_right_deg=m.get("max_rom_right_deg"),
        jerk_score_left=m.get("jerk_score_left"),
        jerk_score_right=m.get("jerk_score_right"),
        symmetry_index_pct=m.get("symmetry_index_pct"),
        velocity_anomaly_count_left=m.get("velocity_anomaly_count_left", 0),
        velocity_anomaly_count_right=m.get("velocity_anomaly_count_right", 0),
        compensation_suspected=m.get("compensation_suspected", False),
    )


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="MediPose-Agent 報告生成（第三階段）")
    parser.add_argument("--analysis", type=str, required=True,
                        help="第二階段輸出的 _analysis.json 路徑")
    parser.add_argument("--corpus", type=str, required=True,
                        help="臨床指引純文字檔路徑（UTF-8）")
    parser.add_argument("--output", type=str, default=None,
                        help="報告輸出路徑，預設為 analysis 檔同目錄加 _report 後綴")
    parser.add_argument("--mock-llm", action="store_true",
                        help="使用 MockLLMClient（不需 Ollama 服務，供驗證流程使用）")
    return parser.parse_args()


def main() -> None:
    logging.basicConfig(
        level=DEFAULT_CONFIG.log_level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    args = _parse_args()
    analysis_path = Path(args.analysis)
    corpus_path = Path(args.corpus)
    output_path = (
        Path(args.output) if args.output
        else analysis_path.with_name(analysis_path.stem + "_report.json")
    )

    # mock-llm 旗標可切換使用 MockLLMClient（不依賴 Ollama）
    config = DEFAULT_CONFIG
    if args.mock_llm:
        from dataclasses import replace
        config = replace(config, llm=LLMConfig(backend="mock"))

    try:
        metrics = _load_metrics_from_analysis_json(analysis_path)
        retriever = build_retriever_from_corpus(corpus_path, config)
        llm_client = create_llm_client(config.llm)
        result = generate_report(metrics, retriever, llm_client, config)
    except (FileNotFoundError, ValueError, RuntimeError) as exc:
        logger.error("報告生成失敗: %s", exc)
        sys.exit(1)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as f:
        json.dump(result.to_dict(), f, ensure_ascii=False, indent=2)

    print(f"報告已輸出至: {output_path}")
    print(f"  可追溯覆蓋率: {result.citation_check.traceability_score:.1%}")
    print(f"  未驗證引用: {result.citation_check.invalid_citation_ids}")


if __name__ == "__main__":
    main()
