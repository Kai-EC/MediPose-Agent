"""
姿態估計模組。

封裝 YOLOv11-Pose 模型載入與推論，處理裝置選擇（CUDA 不可用時自動降級為
CPU 並提出警告），並對輸入影像做基本格式驗證。
"""
from __future__ import annotations

import logging
from typing import Any, Optional

import numpy as np

from .config import PoseModelConfig

logger = logging.getLogger(__name__)


class PoseEstimator:
    """YOLOv11-Pose 模型推論封裝類別。"""

    def __init__(self, config: Optional[PoseModelConfig] = None) -> None:
        """
        Args:
            config: 模型設定，預設使用 PoseModelConfig() 預設值。

        Raises:
            FileNotFoundError: 模型權重檔不存在時拋出。
            ImportError: ultralytics 套件未安裝時拋出。
        """
        self._config = config or PoseModelConfig()

        if not self._config.model_path.exists():
            raise FileNotFoundError(
                f"找不到模型權重檔: {self._config.model_path}，"
                "請確認已下載 YOLOv11-Pose 權重，或於 PoseModelConfig 指定正確路徑。"
            )

        try:
            from ultralytics import YOLO
        except ImportError as exc:
            raise ImportError(
                "未安裝 ultralytics 套件，請執行: pip install ultralytics"
            ) from exc

        self._device = self._resolve_device(self._config.device)
        self._model = YOLO(str(self._config.model_path))
        self._model.to(self._device)
        logger.info(
            "PoseEstimator 已載入模型: path=%s, device=%s",
            self._config.model_path, self._device,
        )

    @staticmethod
    def _resolve_device(requested: str) -> str:
        """依使用者設定與硬體可用性決定實際運算裝置。"""
        if requested != "auto":
            return requested

        import torch

        if torch.cuda.is_available():
            return "cuda"
        logger.warning(
            "未偵測到可用 CUDA 裝置，將降級使用 CPU 進行推論（速度會明顯降低）"
        )
        return "cpu"

    def infer(self, image: np.ndarray) -> Any:
        """
        對單一影格執行姿態估計推論。

        Args:
            image: BGR 格式影像陣列（cv2 讀取格式），shape 應為 (H, W, 3)。

        Returns:
            YOLO 推論結果物件（ultralytics Results）。

        Raises:
            ValueError: 輸入影像格式不正確時拋出。
        """
        if image is None or image.ndim != 3 or image.shape[2] != 3:
            shape_info = None if image is None else image.shape
            raise ValueError(
                f"輸入影像格式不正確，預期 shape=(H, W, 3)，實際收到: {shape_info}"
            )

        results = self._model.predict(
            source=image,
            imgsz=self._config.input_size,
            conf=self._config.confidence_threshold,
            verbose=False,
        )
        return results[0]
