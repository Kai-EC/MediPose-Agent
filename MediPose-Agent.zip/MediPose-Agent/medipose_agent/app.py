"""
MediPose-Agent Gradio 前端介面（第四階段）。

使用 gr.Blocks 實現左右對稱式版面，利用 Python generator（yield）
達到視覺畫面、角度圖表與 AI 診斷報告的非同步串流同步更新。

使用範例：
    python -m medipose_agent.app
    python -m medipose_agent.app --mode demo
    python -m medipose_agent.app --mode analysis_only --analysis path/to/analysis.json
"""
from __future__ import annotations

import argparse
import logging
from dataclasses import replace
from typing import Optional

import gradio as gr

from .config import AppConfig, EmbeddingConfig, LLMConfig, RetrievalConfig
from .ui.backend import run_analysis_from_json, run_demo_mode
from .ui.charts import build_angle_chart, build_metrics_html

logger = logging.getLogger(__name__)

_DEFAULT_CORPUS_PLACEHOLDER = (
    "（可貼入臨床指引文字，例如台灣物理治療學會前十字韌帶術後復健指引...\n"
    "若留空則使用內建簡易指引）"
)

_CSS = """
.gradio-container { max-width: 1280px !important; margin: auto; }
#title-row { text-align: center; padding: 8px 0 4px; }
#status-bar { font-size: 13px; color: #888; min-height: 22px; }
#report-box { min-height: 260px; }
#metrics-box { min-height: 220px; }
"""

_MODE_DESCRIPTIONS = {
    "demo": "🎬 展示模式（合成資料 + Mock LLM，無需任何外部服務）",
    "analysis_only": "📊 分析模式（讀取已有的 analysis.json，執行 RAG + LLM）",
    "full": "🚀 完整模式（Phase 1→2→3 全流程，需 YOLO 模型與 Ollama 服務）",
}


def _build_config(mode: str, llm_backend: str = "mock") -> AppConfig:
    base = AppConfig()
    cfg = replace(
        base,
        embedding=EmbeddingConfig(backend="tfidf", max_features=512),
        retrieval=RetrievalConfig(top_k=3, min_similarity=0.0),
        llm=LLMConfig(backend=llm_backend, temperature=0.2),
    )
    return cfg


def build_app(default_mode: str = "demo", analysis_json: Optional[str] = None) -> gr.Blocks:
    """
    建立並回傳 Gradio Blocks 應用程式物件。

    Args:
        default_mode: 預設執行模式（"demo" | "analysis_only" | "full"）。
        analysis_json: analysis_only 模式的預設 JSON 路徑。

    Returns:
        已設定好事件處理的 gr.Blocks 物件，呼叫 `.launch()` 即可啟動。
    """
    empty_fig = build_angle_chart([], [], title="等待分析...")

    with gr.Blocks(title="MediPose-Agent | 居家復健力學分析") as demo:

        # ── 標題列 ──────────────────────────────────────────────
        with gr.Row(elem_id="title-row"):
            gr.Markdown(
                "# 🦾 MediPose-Agent\n"
                "**邊緣視覺姿態估計 × 在地大語言模型 × 居家復健力學分析**"
            )

        # ── 模式選擇列 ──────────────────────────────────────────
        with gr.Row():
            mode_dropdown = gr.Dropdown(
                choices=list(_MODE_DESCRIPTIONS.keys()),
                value=default_mode,
                label="執行模式",
                info="demo 模式無需任何外部服務，適合面試展示",
                scale=1,
            )
            mode_info = gr.Markdown(
                value=_MODE_DESCRIPTIONS[default_mode], scale=3
            )

        # ── 主要內容：左右雙欄 ──────────────────────────────────
        with gr.Row():

            # ── 左側：感知層輸入 ────────────────────────────────
            with gr.Column(scale=4):
                gr.Markdown("### 📹 感知層輸入")

                video_input = gr.Video(
                    label="復健影片上傳（analysis_only / full 模式使用）",
                    interactive=True,
                )
                analysis_json_input = gr.Textbox(
                    label="analysis.json 路徑（analysis_only 模式）",
                    value=analysis_json or "",
                    placeholder="output/joint_sequences/session_xxx_analysis.json",
                )
                corpus_input = gr.Textbox(
                    label="臨床指引語料庫（可選）",
                    value="",
                    placeholder=_DEFAULT_CORPUS_PLACEHOLDER,
                    lines=4,
                )
                llm_backend_radio = gr.Radio(
                    choices=["mock", "ollama"],
                    value="mock",
                    label="LLM Backend",
                    info="mock：測試用固定回覆 | ollama：需本機啟動 Ollama 服務",
                )
                analyze_btn = gr.Button(
                    "🚀 開始分析", variant="primary", size="lg"
                )
                status_bar = gr.Markdown(
                    value="等待操作...", elem_id="status-bar"
                )

            # ── 右側：分析與決策層輸出 ──────────────────────────
            with gr.Column(scale=6):
                gr.Markdown("### 📊 力學分析 × AI 決策")

                with gr.Row():
                    angle_chart = gr.Plot(
                        value=empty_fig,
                        label="膝關節角度時間序列",
                        scale=3,
                    )
                    metrics_html = gr.HTML(
                        value="<div style='color:#888;padding:20px;'>分析後顯示量化指標</div>",
                        label="量化力學指標",
                        elem_id="metrics-box",
                    )

                gr.Markdown("#### 🤖 AI 物理治療評估報告")
                report_output = gr.Markdown(
                    value="*分析後顯示 AI 診斷報告...*",
                    elem_id="report-box",
                )

        # ── 引用說明列 ──────────────────────────────────────────
        with gr.Row():
            gr.Markdown(
                "<small>⚠️ 本系統為決策支援工具（CDSS），不取代醫師或物理治療師之臨床判斷。"
                "AI 報告引用可追溯覆蓋率已顯示於報告末尾。</small>",
            )

        # ── 事件處理 ─────────────────────────────────────────────

        def on_mode_change(mode: str) -> str:
            return _MODE_DESCRIPTIONS.get(mode, "")

        mode_dropdown.change(
            fn=on_mode_change,
            inputs=[mode_dropdown],
            outputs=[mode_info],
        )

        def on_analyze(
            mode: str,
            analysis_path: str,
            corpus_text: str,
            llm_backend: str,
        ):
            """
            分析主事件函式（generator）。

            透過 yield 實現：圖表逐幀更新 → 指標出現 → 報告逐字串流，
            Gradio 會在每次 yield 後更新對應的 UI 元件。
            """
            config = _build_config(mode, llm_backend)

            if mode == "demo":
                gen = run_demo_mode(config)
            elif mode == "analysis_only":
                if not analysis_path.strip():
                    yield empty_fig, "<div>請輸入 analysis.json 路徑</div>", "❌ 路徑未填寫", "*請先填入 analysis.json 路徑*"
                    return
                gen = run_analysis_from_json(analysis_path.strip(), corpus_text, config)
            else:
                # full 模式：目前暫以 demo 替代（YOLO/完整 pipeline 需在您的環境執行）
                logger.warning("full 模式尚未完整整合，改以 demo 模式執行")
                gen = run_demo_mode(config)

            left_buf: list = []
            right_buf: list = []

            for left_seq, right_seq, metrics, status, html, report in gen:
                left_buf = left_seq if left_seq else left_buf
                right_buf = right_seq if right_seq else right_buf

                if left_buf or right_buf:
                    fig = build_angle_chart(
                        left_filtered=left_buf,
                        right_filtered=right_buf,
                        sampling_hz=config.filtering.sampling_hz,
                    )
                else:
                    fig = empty_fig

                yield fig, html or "", status, report or "*生成中...*"

        analyze_btn.click(
            fn=on_analyze,
            inputs=[mode_dropdown, analysis_json_input, corpus_input, llm_backend_radio],
            outputs=[angle_chart, metrics_html, status_bar, report_output],
        )

    return demo


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="MediPose-Agent Gradio 前端（第四階段）")
    parser.add_argument("--mode", choices=["demo", "analysis_only", "full"], default="demo")
    parser.add_argument("--analysis", type=str, default=None,
                        help="analysis_only 模式的 analysis.json 預設路徑")
    parser.add_argument("--port", type=int, default=7860)
    parser.add_argument("--share", action="store_true", help="產生公開分享連結（需網路）")
    return parser.parse_args()


def main() -> None:
    logging.basicConfig(
        level="INFO",
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    args = _parse_args()
    app = build_app(default_mode=args.mode, analysis_json=args.analysis)
    app.launch(server_port=args.port, share=args.share, css=_CSS)


if __name__ == "__main__":
    main()
