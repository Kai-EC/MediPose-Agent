"""
MediPose-Agent 第一階段：視覺底座主程式。

整合影像擷取、姿態估計與下肢關節提取，提供即時骨架標註預覽，
並於結束時將關節時間序列資料匯出供第二階段力學分析使用。

使用範例：
    python -m medipose_agent.main --source 0
    python -m medipose_agent.main --source path/to/video.mp4 --no-display
"""
from __future__ import annotations

import argparse
import logging
import signal
import sys
import time
from pathlib import Path
from typing import Optional, Union

import cv2
import numpy as np

from .buffer import JointSequenceBuffer
from .capture import CapturedFrame, VideoStreamReader
from .config import DEFAULT_CONFIG
from .joint_extractor import JointFrame, LowerBodyJointExtractor
from .pose_estimator import PoseEstimator

logger = logging.getLogger(__name__)

_SKELETON_EDGES: tuple[tuple[str, str], ...] = (
    ("left_hip", "right_hip"),
    ("left_hip", "left_knee"),
    ("left_knee", "left_ankle"),
    ("right_hip", "right_knee"),
    ("right_knee", "right_ankle"),
)


def _draw_skeleton(image: np.ndarray, joint_frame: JointFrame) -> np.ndarray:
    """於影像上繪製下肢骨架標註，供即時視覺化檢查使用。"""
    annotated = image.copy()

    for point in joint_frame.joints.values():
        center = (int(point.x), int(point.y))
        cv2.circle(annotated, center, radius=5, color=(0, 255, 0), thickness=-1)

    for start_name, end_name in _SKELETON_EDGES:
        start = joint_frame.joints.get(start_name)
        end = joint_frame.joints.get(end_name)
        if start is None or end is None:
            continue
        cv2.line(
            annotated,
            (int(start.x), int(start.y)),
            (int(end.x), int(end.y)),
            color=(255, 128, 0),
            thickness=2,
        )

    if joint_frame.multi_person_warning:
        cv2.putText(
            annotated, "WARNING: Multiple persons detected",
            (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2,
        )

    return annotated


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="MediPose-Agent 視覺底座（第一階段）")
    parser.add_argument(
        "--source", type=str, default="0",
        help="影像來源：Webcam 索引（如 0）或影片檔案路徑，預設為 0",
    )
    parser.add_argument(
        "--no-display", action="store_true",
        help="關閉即時預覽視窗（適用於無頭伺服器環境）",
    )
    parser.add_argument(
        "--export-name", type=str, default=None,
        help="結束時匯出的 JSON 檔名，預設依時間戳記自動產生",
    )
    return parser.parse_args()


def _resolve_source(raw_source: str) -> Union[int, str]:
    """將字串型態的命令列參數轉換為 webcam 索引或檔案路徑字串。"""
    return int(raw_source) if raw_source.isdigit() else raw_source


def run(
    source: Union[int, str],
    display: bool = True,
    export_name: Optional[str] = None,
) -> Path:
    """
    執行第一階段視覺底座主流程。

    Args:
        source: Webcam 索引或影片檔案路徑。
        display: 是否開啟即時預覽視窗。
        export_name: 匯出檔名，None 時自動依時間戳記產生。

    Returns:
        匯出的 JSON 檔案路徑。
    """
    pose_estimator = PoseEstimator(DEFAULT_CONFIG.pose_model)
    extractor = LowerBodyJointExtractor(DEFAULT_CONFIG.pose_model.confidence_threshold)
    buffer = JointSequenceBuffer(DEFAULT_CONFIG.buffer)

    stop_requested = False

    def _handle_sigint(signum: int, frame: object) -> None:
        nonlocal stop_requested
        logger.info("收到中斷訊號，準備安全結束並匯出資料...")
        stop_requested = True

    signal.signal(signal.SIGINT, _handle_sigint)

    with VideoStreamReader(source, DEFAULT_CONFIG.capture) as stream:
        while not stop_requested:
            captured: Optional[CapturedFrame] = stream.read(timeout=1.0)
            if captured is None:
                if not stream.is_running:
                    logger.info("影像來源已結束")
                    break
                continue

            try:
                result = pose_estimator.infer(captured.image)
            except ValueError as exc:
                logger.error("姿態推論輸入錯誤，跳過此影格: %s", exc)
                continue

            joint_frame = extractor.extract(captured.frame_id, captured.timestamp, result)
            buffer.append(joint_frame)

            if display:
                annotated = _draw_skeleton(captured.image, joint_frame)
                cv2.imshow("MediPose-Agent | Phase 1 Preview", annotated)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    stop_requested = True

    if display:
        cv2.destroyAllWindows()

    quality = buffer.stats
    logger.info(
        "擷取結束: 總影格=%d, 有效偵測率=%.1f%%, 多人警示比例=%.1f%%",
        quality["total_frames"],
        quality["valid_ratio"] * 100,
        quality["multi_person_ratio"] * 100,
    )

    file_name = export_name or f"session_{int(time.time())}.json"
    return buffer.export(file_name)


def main() -> None:
    logging.basicConfig(
        level=DEFAULT_CONFIG.log_level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    args = _parse_args()

    try:
        output_path = run(
            source=_resolve_source(args.source),
            display=not args.no_display,
            export_name=args.export_name,
        )
    except (FileNotFoundError, ImportError, RuntimeError, ValueError) as exc:
        logger.error("程式執行失敗: %s", exc)
        sys.exit(1)

    print(f"關節序列資料已匯出至: {output_path}")


if __name__ == "__main__":
    main()
