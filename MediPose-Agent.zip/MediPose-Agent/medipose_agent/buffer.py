"""
關節資料緩衝區模組。

以執行緒安全的有界佇列保存時間序列關節資料，提供匯出（供第二階段
力學分析讀取）與基本品質統計（有效偵測率、多人警示比例）功能。
"""
from __future__ import annotations

import json
import logging
import threading
from collections import deque
from pathlib import Path
from typing import Deque, Optional

from .config import BufferConfig
from .joint_extractor import JointFrame

logger = logging.getLogger(__name__)


class JointSequenceBuffer:
    """執行緒安全的關節時間序列緩衝區。"""

    def __init__(self, config: Optional[BufferConfig] = None) -> None:
        """
        Args:
            config: 緩衝區設定，預設使用 BufferConfig() 預設值。
        """
        self._config = config or BufferConfig()
        self._buffer: Deque[JointFrame] = deque(maxlen=self._config.max_frames)
        self._lock = threading.Lock()

    def append(self, joint_frame: JointFrame) -> None:
        """新增一筆關節影格資料（執行緒安全）。"""
        with self._lock:
            if len(self._buffer) == self._buffer.maxlen:
                logger.warning(
                    "緩衝區已達上限 (%d 影格)，最舊資料將被覆蓋，"
                    "建議定期呼叫 export() 落地保存",
                    self._config.max_frames,
                )
            self._buffer.append(joint_frame)

    def __len__(self) -> int:
        with self._lock:
            return len(self._buffer)

    def get_all(self) -> list[JointFrame]:
        """取得目前緩衝區內所有影格資料的快照（不清空緩衝區）。"""
        with self._lock:
            return list(self._buffer)

    def clear(self) -> None:
        """清空緩衝區。"""
        with self._lock:
            self._buffer.clear()

    @property
    def stats(self) -> dict[str, float]:
        """計算目前緩衝區的基本品質統計，供使用者判斷拍攝品質。"""
        with self._lock:
            frames = list(self._buffer)

        if not frames:
            return {"total_frames": 0, "valid_ratio": 0.0, "multi_person_ratio": 0.0}

        valid_count = sum(1 for f in frames if f.person_detected)
        multi_person_count = sum(1 for f in frames if f.multi_person_warning)

        return {
            "total_frames": len(frames),
            "valid_ratio": valid_count / len(frames),
            "multi_person_ratio": multi_person_count / len(frames),
        }

    def export(self, file_name: str) -> Path:
        """
        將目前緩衝區資料匯出為 JSON 檔案，供第二階段力學分析模組讀取。

        Args:
            file_name: 輸出檔名（不含路徑），例如 "session_20260619.json"。

        Returns:
            實際寫入的檔案完整路徑。

        Raises:
            ValueError: 緩衝區為空時拋出，避免產生無效的空檔案。
        """
        frames = self.get_all()
        if not frames:
            raise ValueError("緩衝區為空，無資料可匯出")

        self._config.export_dir.mkdir(parents=True, exist_ok=True)
        output_path = self._config.export_dir / file_name

        payload = {
            "frame_count": len(frames),
            "quality_stats": self.stats,
            "frames": [f.to_dict() for f in frames],
        }

        with output_path.open("w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)

        logger.info(
            "關節序列資料已匯出: path=%s, frame_count=%d", output_path, len(frames)
        )
        return output_path
