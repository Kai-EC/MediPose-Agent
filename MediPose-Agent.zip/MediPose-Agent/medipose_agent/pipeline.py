"""
MediPose-Agent 第二階段：生物力學分析主流程。

讀取第一階段匯出的關節序列 JSON，依序執行：
    1. 向量幾何法計算左右膝關節原始角度序列
    2. 視角自適應幾何補償
    3. 巴特沃斯低通濾波（零相位）
    4. 特徵聚合（Max ROM、Jerk Score、Symmetry Index、代償偵測）
並將完整結果輸出為 JSON，供第三階段 LLM 報告生成模組使用。

使用範例：
    python -m medipose_agent.pipeline --input output/joint_sequences/session_xxx.json
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional

from .biomechanics.correction import (
    CorrectedAngle,
    correct_frame_angle,
    estimate_reference_lengths,
)
from .biomechanics.filtering import butterworth_lowpass_filter
from .biomechanics.geometry import KNEE_TRIPLETS, JointTriplet, compute_angle_sequence
from .biomechanics.metrics import SessionMetrics, aggregate_session_metrics
from .config import DEFAULT_CONFIG, AppConfig
from .io_utils import load_joint_sequence
from .joint_extractor import JointFrame

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class KneeAnalysis:
    """單側膝關節的完整分析結果。"""

    raw_angles_deg: list[Optional[float]]
    corrected_angles_deg: list[Optional[float]]
    filtered_angles_deg: list[Optional[float]]
    phi_deg: list[Optional[float]]
    reliable_frame_ratio: float
    dual_segment_disagreement_count: int


@dataclass(slots=True)
class SessionAnalysisResult:
    """完整 session 的第二階段分析結果。"""

    source_file: str
    frame_count: int
    sampling_hz: float
    left_knee: KneeAnalysis
    right_knee: KneeAnalysis
    metrics: SessionMetrics

    def to_dict(self) -> dict:
        return {
            "source_file": self.source_file,
            "frame_count": self.frame_count,
            "sampling_hz": self.sampling_hz,
            "left_knee": asdict(self.left_knee),
            "right_knee": asdict(self.right_knee),
            "metrics": asdict(self.metrics),
        }


def _analyze_single_knee(
    frames: list[JointFrame], triplet: JointTriplet, config: AppConfig
) -> KneeAnalysis:
    """對單側膝關節執行角度計算、視角補償與濾波的完整子流程。"""
    raw_angles = compute_angle_sequence(frames, triplet)

    reference_lengths = estimate_reference_lengths(
        frames,
        triplet.proximal,
        triplet.vertex,
        triplet.distal,
        config.correction.calibration_frame_count,
    )

    corrected_angles: list[Optional[float]] = []
    phi_values: list[Optional[float]] = []
    disagreement_count = 0
    reliable_count = 0

    for frame, raw_angle in zip(frames, raw_angles):
        proximal = frame.joints.get(triplet.proximal)
        vertex = frame.joints.get(triplet.vertex)
        distal = frame.joints.get(triplet.distal)

        if raw_angle is None or reference_lengths is None or not (proximal and vertex and distal):
            corrected_angles.append(None)
            phi_values.append(None)
            continue

        result: CorrectedAngle = correct_frame_angle(
            raw_angle, proximal, vertex, distal, reference_lengths, config.correction
        )
        corrected_angles.append(result.theta_corrected_deg)
        phi_values.append(result.phi_deg)
        if result.is_reliable:
            reliable_count += 1
        if result.dual_segment_disagreement_flag:
            disagreement_count += 1

    filtered_angles = butterworth_lowpass_filter(corrected_angles, config.filtering)

    total = len(frames) if frames else 1
    return KneeAnalysis(
        raw_angles_deg=raw_angles,
        corrected_angles_deg=corrected_angles,
        filtered_angles_deg=filtered_angles,
        phi_deg=phi_values,
        reliable_frame_ratio=reliable_count / total,
        dual_segment_disagreement_count=disagreement_count,
    )


def analyze_session(
    input_path: Path, config: Optional[AppConfig] = None
) -> SessionAnalysisResult:
    """
    執行完整第二階段分析流程。

    Args:
        input_path: 第一階段匯出的關節序列 JSON 檔案路徑。
        config: 應用程式設定，預設使用 DEFAULT_CONFIG。

    Returns:
        完整的 session 分析結果。

    Raises:
        FileNotFoundError: 輸入檔案不存在時拋出。
        ValueError: 輸入檔案內無任何影格資料時拋出。
    """
    cfg = config or DEFAULT_CONFIG
    frames = load_joint_sequence(input_path)

    if not frames:
        raise ValueError(f"輸入檔案無任何影格資料: {input_path}")

    left_analysis = _analyze_single_knee(frames, KNEE_TRIPLETS["left"], cfg)
    right_analysis = _analyze_single_knee(frames, KNEE_TRIPLETS["right"], cfg)

    metrics = aggregate_session_metrics(
        left_analysis.filtered_angles_deg,
        right_analysis.filtered_angles_deg,
        cfg.filtering.sampling_hz,
        cfg.metrics,
    )

    return SessionAnalysisResult(
        source_file=str(input_path),
        frame_count=len(frames),
        sampling_hz=cfg.filtering.sampling_hz,
        left_knee=left_analysis,
        right_knee=right_analysis,
        metrics=metrics,
    )


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="MediPose-Agent 生物力學分析（第二階段）")
    parser.add_argument(
        "--input", type=str, required=True, help="第一階段匯出的關節序列 JSON 檔案路徑"
    )
    parser.add_argument(
        "--output", type=str, default=None,
        help="分析結果輸出路徑，預設為輸入檔同目錄下加上 _analysis 後綴",
    )
    return parser.parse_args()


def main() -> None:
    logging.basicConfig(
        level=DEFAULT_CONFIG.log_level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    args = _parse_args()
    input_path = Path(args.input)
    output_path = (
        Path(args.output)
        if args.output
        else input_path.with_name(input_path.stem + "_analysis.json")
    )

    try:
        result = analyze_session(input_path)
    except (FileNotFoundError, ValueError) as exc:
        logger.error("分析失敗: %s", exc)
        sys.exit(1)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as f:
        json.dump(result.to_dict(), f, ensure_ascii=False, indent=2)

    logger.info("分析結果已輸出: %s", output_path)
    print(f"分析結果已輸出至: {output_path}")
    print(f"  左膝 Max ROM: {result.metrics.max_rom_left_deg}")
    print(f"  右膝 Max ROM: {result.metrics.max_rom_right_deg}")
    print(f"  對稱指數: {result.metrics.symmetry_index_pct}")
    print(f"  疑似代償: {result.metrics.compensation_suspected}")


if __name__ == "__main__":
    main()
