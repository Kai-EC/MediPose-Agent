"""
MediPose-Agent 效能基準測試腳本（第五階段）。

自動量測並輸出可放入備審資料的效能數據：
- Phase 2 生物力學演算法處理速度（純 CPU，任何環境皆可跑）
- Phase 3 RAG 建索引與檢索延遲
- Phase 3 MockLLM / Ollama 推論延遲（Ollama 需本機啟動）
- 完整 Pipeline 端到端延遲（Phase 2 + Phase 3）

使用範例：
    python -m medipose_agent.benchmark
    python -m medipose_agent.benchmark --with-ollama   # 含 Ollama 推論測試
    python -m medipose_agent.benchmark --output benchmark_result.json
"""
from __future__ import annotations

import argparse
import json
import logging
import math
import statistics
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Callable, Optional

from .biomechanics.filtering import butterworth_lowpass_filter
from .biomechanics.metrics import aggregate_session_metrics
from .biomechanics.geometry import KNEE_TRIPLETS
from .config import (
    AppConfig, EmbeddingConfig, FilterConfig,
    LLMConfig, RetrievalConfig,
)
from .llm.client import MockLLMClient
from .llm.prompt_builder import build_retrieval_query, build_user_prompt, _SYSTEM_PROMPT
from .llm.citation_checker import CitationChecker
from .rag.document_loader import chunk_text
from .rag.retriever import Retriever

logger = logging.getLogger(__name__)

_BENCHMARK_CORPUS = """
前十字韌帶重建術後復健指引。術後第一週目標為消腫、減痛及恢復關節活動度。
患者應進行主動輔助式屈膝訓練，目標角度為九十度。
若屈曲角度未達九十度，建議增加股四頭肌離心訓練頻率。
左右肢體對稱指數正常範圍為 ±15%。超過此範圍表示患側代償可能已發生。
運動平滑度（Jerk Score）反映神經肌肉控制品質，數值越接近零代表動作控制越佳。
代償動作偵測：角速度突波超過每秒 300 度視為可能代償。
人工關節置換術後膝關節活動度恢復目標：術後三個月達 110 度以上。
"""

_REPEAT = 30  # 每項測試重複次數，取中位數以降低系統波動影響


@dataclass
class BenchmarkItem:
    name: str
    unit: str
    median: float
    min_val: float
    max_val: float
    stdev: float
    note: str = ""


@dataclass
class BenchmarkReport:
    timestamp: str
    system_note: str
    items: list[BenchmarkItem] = field(default_factory=list)

    def print_table(self) -> None:
        print(f"\n{'=' * 68}")
        print(f"  MediPose-Agent 效能基準測試報告")
        print(f"  {self.timestamp}  |  {self.system_note}")
        print(f"{'=' * 68}")
        header = f"{'項目':<32} {'中位數':>10} {'最小':>8} {'最大':>8} {'單位':<6}"
        print(header)
        print("-" * 68)
        for item in self.items:
            print(
                f"{item.name:<32} {item.median:>10.2f} "
                f"{item.min_val:>8.2f} {item.max_val:>8.2f} {item.unit:<6}"
                + (f"  ← {item.note}" if item.note else "")
            )
        print("=" * 68)

    def to_dict(self) -> dict:
        return asdict(self)


def _time_fn(fn: Callable, repeat: int = _REPEAT) -> tuple[float, float, float, float]:
    """執行函式 repeat 次，回傳 (中位數, 最小, 最大, 標準差)，單位毫秒。"""
    times_ms = []
    for _ in range(repeat):
        t0 = time.perf_counter()
        fn()
        times_ms.append((time.perf_counter() - t0) * 1000)
    return (
        statistics.median(times_ms),
        min(times_ms),
        max(times_ms),
        statistics.stdev(times_ms) if len(times_ms) > 1 else 0.0,
    )


def _generate_synthetic_frames(n: int = 180, sampling_hz: float = 30.0) -> list:
    """產生合成關節影格序列（6 秒，30FPS），供 Phase 2 基準測試使用。"""
    from .joint_extractor import JointFrame, JointPoint

    frames = []
    for i in range(n):
        t = i / sampling_hz
        theta_deg = 135.0 - 45.0 * math.cos(2 * math.pi * t / 3.0)
        theta_rad = math.radians(theta_deg)
        ankle_x = 80.0 * math.sin(theta_rad)
        ankle_y = -80.0 * math.cos(theta_rad)
        frames.append(JointFrame(
            frame_id=i, timestamp=t, person_detected=True,
            joints={
                "left_hip": JointPoint(0.0, 100.0, 0.95),
                "left_knee": JointPoint(0.0, 0.0, 0.95),
                "left_ankle": JointPoint(ankle_x, ankle_y, 0.95),
                "right_hip": JointPoint(200.0, 100.0, 0.95),
                "right_knee": JointPoint(200.0, 0.0, 0.95),
                "right_ankle": JointPoint(200.0 + ankle_x, ankle_y, 0.95),
            }
        ))
    return frames


def run_phase2_benchmarks(report: BenchmarkReport, n_frames: int = 180) -> None:
    """量測 Phase 2 生物力學演算法的各步驟處理速度。"""
    from .biomechanics.geometry import compute_angle_sequence
    from .biomechanics.correction import estimate_reference_lengths, correct_frame_angle

    frames = _generate_synthetic_frames(n_frames)
    triplet = KNEE_TRIPLETS["left"]
    filter_cfg = FilterConfig()

    # 1. 關節角度計算
    med, mn, mx, std = _time_fn(
        lambda: compute_angle_sequence(frames, triplet)
    )
    report.items.append(BenchmarkItem(
        name=f"關節角度計算（{n_frames} 幀）",
        unit="ms", median=med, min_val=mn, max_val=mx, stdev=std,
        note=f"≈ {n_frames / (med / 1000):.0f} FPS 等效處理速度",
    ))

    # 2. 視角補償（含基準長度估算）
    angles = compute_angle_sequence(frames, triplet)
    ref = estimate_reference_lengths(
        frames, triplet.proximal, triplet.vertex, triplet.distal, 15
    )

    def _correct_all():
        for frame, angle in zip(frames, angles):
            if angle is None or ref is None:
                continue
            p = frame.joints.get(triplet.proximal)
            v = frame.joints.get(triplet.vertex)
            d = frame.joints.get(triplet.distal)
            if p and v and d:
                correct_frame_angle(angle, p, v, d, ref)

    med, mn, mx, std = _time_fn(_correct_all)
    report.items.append(BenchmarkItem(
        name=f"視角補償計算（{n_frames} 幀）",
        unit="ms", median=med, min_val=mn, max_val=mx, stdev=std,
    ))

    # 3. 巴特沃斯濾波
    seq = [float(i) for i in range(n_frames)]
    med, mn, mx, std = _time_fn(
        lambda: butterworth_lowpass_filter(seq, filter_cfg)
    )
    report.items.append(BenchmarkItem(
        name=f"巴特沃斯濾波（{n_frames} 幀）",
        unit="ms", median=med, min_val=mn, max_val=mx, stdev=std,
    ))

    # 4. 特徵聚合（4 項指標）
    filtered = butterworth_lowpass_filter(seq, filter_cfg)
    med, mn, mx, std = _time_fn(
        lambda: aggregate_session_metrics(filtered, filtered, 30.0)
    )
    report.items.append(BenchmarkItem(
        name="特徵聚合（ROM + Jerk + SI + 代償）",
        unit="ms", median=med, min_val=mn, max_val=mx, stdev=std,
    ))

    # 5. Phase 2 完整 pipeline（端到端）
    def _full_phase2():
        seqs = compute_angle_sequence(frames, triplet)
        filt = butterworth_lowpass_filter(seqs, filter_cfg)
        aggregate_session_metrics(filt, filt, 30.0)

    med, mn, mx, std = _time_fn(_full_phase2)
    throughput = n_frames / (med / 1000)
    report.items.append(BenchmarkItem(
        name=f"Phase 2 完整流程（{n_frames} 幀）",
        unit="ms", median=med, min_val=mn, max_val=mx, stdev=std,
        note=f"吞吐量 {throughput:.0f} 幀/秒（遠超即時需求 30 FPS）",
    ))


def run_phase3_benchmarks(
    report: BenchmarkReport, with_ollama: bool = False
) -> None:
    """量測 Phase 3 RAG 與 LLM 推論延遲。"""
    from .biomechanics.metrics import SessionMetrics

    metrics = SessionMetrics(
        max_rom_left_deg=85.0, max_rom_right_deg=95.0,
        jerk_score_left=-7.5, jerk_score_right=-7.2,
        symmetry_index_pct=10.5,
        velocity_anomaly_count_left=0, velocity_anomaly_count_right=0,
        compensation_suspected=False,
    )

    cfg = AppConfig(
        embedding=EmbeddingConfig(backend="tfidf", max_features=512),
        retrieval=RetrievalConfig(top_k=3, min_similarity=0.0),
        llm=LLMConfig(backend="mock"),
    )

    # 1. RAG 建索引
    chunks = chunk_text(_BENCHMARK_CORPUS, source="bench", config=cfg.chunking)

    def _build_index():
        r = Retriever(embedding_config=cfg.embedding, retrieval_config=cfg.retrieval)
        r.build_index(chunks)
        return r

    med, mn, mx, std = _time_fn(_build_index, repeat=10)
    report.items.append(BenchmarkItem(
        name=f"RAG 建索引（{len(chunks)} 片段）",
        unit="ms", median=med, min_val=mn, max_val=mx, stdev=std,
        note="一次性初始化，不影響每次推論速度",
    ))

    # 2. RAG 檢索
    retriever = _build_index()
    query = build_retrieval_query(metrics)

    med, mn, mx, std = _time_fn(lambda: retriever.query(query))
    report.items.append(BenchmarkItem(
        name="RAG 向量檢索（Top-3）",
        unit="ms", median=med, min_val=mn, max_val=mx, stdev=std,
    ))

    # 3. Prompt 組裝 + 引用驗證
    retrieved = retriever.query(query)

    def _prompt_and_check():
        prompt = build_user_prompt(metrics, retrieved)
        checker = CitationChecker(config=cfg.citation)
        checker.check(
            MockLLMClient().generate(_SYSTEM_PROMPT, prompt),
            {r.chunk.chunk_id for r in retrieved},
        )

    med, mn, mx, std = _time_fn(_prompt_and_check)
    report.items.append(BenchmarkItem(
        name="Prompt 組裝 + Mock LLM + 引用驗證",
        unit="ms", median=med, min_val=mn, max_val=mx, stdev=std,
    ))

    # 4. Ollama 推論（可選，需本機服務）
    if with_ollama:
        from .llm.client import OllamaClient
        ollama_cfg = LLMConfig(backend="ollama")
        client = OllamaClient(ollama_cfg)
        user_prompt = build_user_prompt(metrics, retrieved)

        try:
            med, mn, mx, std = _time_fn(
                lambda: client.generate(_SYSTEM_PROMPT, user_prompt),
                repeat=5,
            )
            report.items.append(BenchmarkItem(
                name=f"Ollama 推論（{ollama_cfg.model_name}）",
                unit="ms", median=med, min_val=mn, max_val=mx, stdev=std,
                note="含首 token 延遲，完整報告生成時間",
            ))
        except RuntimeError as exc:
            logger.warning("Ollama 測試跳過（服務未啟動）: %s", exc)
            report.items.append(BenchmarkItem(
                name="Ollama 推論（未測試）",
                unit="ms", median=0, min_val=0, max_val=0, stdev=0,
                note="Ollama 服務未啟動，請加上 --with-ollama 並確認服務已運行",
            ))


def run_full_pipeline_benchmark(report: BenchmarkReport) -> None:
    """量測 Phase 2 + Phase 3（MockLLM）完整端對端延遲。"""
    from .biomechanics.geometry import compute_angle_sequence
    from .biomechanics.metrics import SessionMetrics

    frames = _generate_synthetic_frames(180)
    triplet_left = KNEE_TRIPLETS["left"]
    triplet_right = KNEE_TRIPLETS["right"]
    filter_cfg = FilterConfig()
    cfg = AppConfig(
        embedding=EmbeddingConfig(backend="tfidf", max_features=512),
        retrieval=RetrievalConfig(top_k=3, min_similarity=0.0),
        llm=LLMConfig(backend="mock"),
    )
    chunks = chunk_text(_BENCHMARK_CORPUS, source="bench", config=cfg.chunking)
    retriever = Retriever(embedding_config=cfg.embedding, retrieval_config=cfg.retrieval)
    retriever.build_index(chunks)
    checker = CitationChecker(config=cfg.citation)
    llm = MockLLMClient()

    def _e2e():
        # Phase 2
        left_angles = compute_angle_sequence(frames, triplet_left)
        right_angles = compute_angle_sequence(frames, triplet_right)
        left_f = butterworth_lowpass_filter(left_angles, filter_cfg)
        right_f = butterworth_lowpass_filter(right_angles, filter_cfg)
        metrics = aggregate_session_metrics(left_f, right_f, 30.0)
        # Phase 3
        query = build_retrieval_query(metrics)
        retrieved = retriever.query(query)
        report_text = llm.generate(_SYSTEM_PROMPT, build_user_prompt(metrics, retrieved))
        checker.check(report_text, {r.chunk.chunk_id for r in retrieved})

    med, mn, mx, std = _time_fn(_e2e, repeat=20)
    report.items.append(BenchmarkItem(
        name="端對端完整流程（Phase 2+3, 180 幀）",
        unit="ms", median=med, min_val=mn, max_val=mx, stdev=std,
        note="不含 Phase 1 視覺推論（需實際環境量測）",
    ))


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="MediPose-Agent 效能基準測試")
    parser.add_argument("--with-ollama", action="store_true",
                        help="納入 Ollama LLM 推論測試（需本機已啟動 Ollama 服務）")
    parser.add_argument("--output", type=str, default=None,
                        help="輸出 JSON 路徑（選填）")
    parser.add_argument("--frames", type=int, default=180,
                        help="Phase 2 基準測試使用的合成影格數（預設 180，即 6 秒 @30FPS）")
    return parser.parse_args()


def main() -> None:
    logging.basicConfig(level="WARNING")
    args = _parse_args()

    import datetime, platform
    report = BenchmarkReport(
        timestamp=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        system_note=f"Python {platform.python_version()} / {platform.system()}",
    )

    print("▶ Phase 2 生物力學演算法基準測試...")
    run_phase2_benchmarks(report, n_frames=args.frames)

    print("▶ Phase 3 RAG + LLM 基準測試...")
    run_phase3_benchmarks(report, with_ollama=args.with_ollama)

    print("▶ 端對端完整流程基準測試...")
    run_full_pipeline_benchmark(report)

    report.print_table()

    if args.output:
        out = Path(args.output)
        out.parent.mkdir(parents=True, exist_ok=True)
        with out.open("w", encoding="utf-8") as f:
            json.dump(report.to_dict(), f, ensure_ascii=False, indent=2)
        print(f"\n結果已輸出至: {out}")


if __name__ == "__main__":
    main()
