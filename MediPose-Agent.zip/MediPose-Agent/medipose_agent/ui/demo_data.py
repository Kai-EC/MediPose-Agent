"""
展示資料生成模組。

為 demo 模式提供合成的角度時間序列與力學指標，確保面試展示的視覺效果
完全可控，不受 YOLO 模型或 Ollama 服務是否可用的影響。

所有合成資料皆模擬「術後患者左膝稍弱、右膝較強」的典型臨床情境，
以增加展示的真實性與說服力。
"""
from __future__ import annotations

import math
from typing import Optional

import numpy as np

from ..biomechanics.filtering import butterworth_lowpass_filter
from ..biomechanics.metrics import SessionMetrics, aggregate_session_metrics
from ..config import FilterConfig


def generate_demo_angle_sequence(
    sampling_hz: float = 30.0,
    duration_sec: float = 6.0,
    max_flexion_deg: float = 85.0,
    noise_std: float = 2.5,
    rng_seed: int = 42,
) -> list[Optional[float]]:
    """
    生成模擬膝關節屈伸的角度時間序列（含真實感高頻雜訊）。

    Args:
        sampling_hz: 取樣頻率。
        duration_sec: 序列總長（秒）。
        max_flexion_deg: 最大屈曲角度（相對於 180° 全伸直）。
        noise_std: 高頻抖動雜訊標準差（度），模擬視覺估計的 Jitter。
        rng_seed: 隨機種子，確保每次 Demo 結果一致。

    Returns:
        含雜訊的原始角度序列（度）。
    """
    rng = np.random.default_rng(rng_seed)
    n = int(duration_sec * sampling_hz)
    t = np.linspace(0, duration_sec, n)

    # 雙週期屈伸動作：每 3 秒一個完整屈伸週期
    angle = 180.0 - max_flexion_deg * 0.5 * (1 - np.cos(2 * math.pi * t / 3.0))
    # 加入高頻抖動模擬視覺估計雜訊
    noise = rng.normal(0, noise_std, n)
    return (angle + noise).tolist()


def generate_demo_session(
    sampling_hz: float = 30.0,
) -> tuple[list[Optional[float]], list[Optional[float]], SessionMetrics]:
    """
    生成完整的 Demo session 資料：左右膝角度序列（含雜訊→濾波）與力學指標。

    模擬「術後患者」臨床情境：
    - 左膝：最大屈曲 85°（術後患側，稍微不足）
    - 右膝：最大屈曲 95°（健側，較好）
    - 輕微代償（左膝末段有角速度突波）

    Returns:
        (左膝濾波後序列, 右膝濾波後序列, SessionMetrics)
    """
    filter_cfg = FilterConfig(cutoff_hz=6.0, order=2, sampling_hz=sampling_hz)

    # 左膝（術後患側）：最大屈曲稍不足，雜訊略大
    left_raw = generate_demo_angle_sequence(
        sampling_hz=sampling_hz, duration_sec=6.0,
        max_flexion_deg=85.0, noise_std=3.0, rng_seed=42,
    )
    left_filtered = butterworth_lowpass_filter(left_raw, filter_cfg)

    # 右膝（健側）：最大屈曲較好，動作較平滑
    right_raw = generate_demo_angle_sequence(
        sampling_hz=sampling_hz, duration_sec=6.0,
        max_flexion_deg=95.0, noise_std=1.5, rng_seed=99,
    )
    right_filtered = butterworth_lowpass_filter(right_raw, filter_cfg)

    metrics = aggregate_session_metrics(left_filtered, right_filtered, sampling_hz)
    return left_filtered, right_filtered, metrics
