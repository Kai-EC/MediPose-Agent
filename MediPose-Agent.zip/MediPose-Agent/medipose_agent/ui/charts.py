"""
Plotly 圖表生成模組。

提供「原始 vs 濾波角度對比圖」與「雙膝對稱比較圖」兩種視覺化，
以及即時逐幀動畫更新用的漸進式圖表建構函式（供 Gradio yield 串流使用）。
"""
from __future__ import annotations

from typing import Any, Optional

import numpy as np
import plotly.graph_objects as go


_COLOR_LEFT_RAW = "rgba(239, 83, 80, 0.35)"     # 淡紅（左膝原始）
_COLOR_LEFT_FILTERED = "#EF5350"                  # 紅（左膝濾波）
_COLOR_RIGHT_RAW = "rgba(66, 165, 245, 0.35)"    # 淡藍（右膝原始）
_COLOR_RIGHT_FILTERED = "#42A5F5"                 # 藍（右膝濾波）
_CHART_BG = "rgba(0,0,0,0)"
_PAPER_BG = "rgba(0,0,0,0)"


def _time_axis(n_samples: int, sampling_hz: float) -> list[float]:
    return [i / sampling_hz for i in range(n_samples)]


def build_angle_chart(
    left_filtered: list[Optional[float]],
    right_filtered: list[Optional[float]],
    left_raw: Optional[list[Optional[float]]] = None,
    right_raw: Optional[list[Optional[float]]] = None,
    sampling_hz: float = 30.0,
    title: str = "膝關節角度時間序列",
) -> go.Figure:
    """
    建立雙膝關節角度時間序列圖（可同時顯示原始與濾波後曲線）。

    Args:
        left_filtered: 左膝濾波後角度序列。
        right_filtered: 右膝濾波後角度序列。
        left_raw: 左膝原始角度序列（可選，顯示時以半透明細線呈現）。
        right_raw: 右膝原始角度序列（可選）。
        sampling_hz: 取樣頻率，用於計算時間軸。
        title: 圖表標題。

    Returns:
        Plotly Figure 物件，可直接傳入 `gr.Plot`。
    """
    n = max(len(left_filtered), len(right_filtered))
    t = _time_axis(n, sampling_hz)

    fig = go.Figure()

    # 原始雜訊曲線（半透明，對比濾波效果）
    if left_raw is not None:
        t_raw = _time_axis(len(left_raw), sampling_hz)
        fig.add_trace(go.Scatter(
            x=t_raw, y=left_raw, mode="lines", name="左膝（原始）",
            line=dict(color=_COLOR_LEFT_RAW, width=1), showlegend=True,
        ))
    if right_raw is not None:
        t_raw = _time_axis(len(right_raw), sampling_hz)
        fig.add_trace(go.Scatter(
            x=t_raw, y=right_raw, mode="lines", name="右膝（原始）",
            line=dict(color=_COLOR_RIGHT_RAW, width=1), showlegend=True,
        ))

    # 濾波後平滑曲線（主要呈現）
    t_left = _time_axis(len(left_filtered), sampling_hz)
    left_values = [v if v is not None else float("nan") for v in left_filtered]
    fig.add_trace(go.Scatter(
        x=t_left, y=left_values, mode="lines", name="左膝（濾波後）",
        line=dict(color=_COLOR_LEFT_FILTERED, width=2.5),
    ))

    t_right = _time_axis(len(right_filtered), sampling_hz)
    right_values = [v if v is not None else float("nan") for v in right_filtered]
    fig.add_trace(go.Scatter(
        x=t_right, y=right_values, mode="lines", name="右膝（濾波後）",
        line=dict(color=_COLOR_RIGHT_FILTERED, width=2.5),
    ))

    fig.update_layout(
        title=dict(text=title, font=dict(size=15)),
        xaxis=dict(title="時間（秒）", gridcolor="rgba(200,200,200,0.3)"),
        yaxis=dict(title="關節角度（度）", range=[60, 195], gridcolor="rgba(200,200,200,0.3)"),
        legend=dict(orientation="h", y=-0.2),
        plot_bgcolor=_CHART_BG,
        paper_bgcolor=_PAPER_BG,
        margin=dict(l=50, r=20, t=50, b=60),
        height=320,
    )
    return fig


def build_progressive_chart(
    left_so_far: list[Optional[float]],
    right_so_far: list[Optional[float]],
    sampling_hz: float = 30.0,
) -> go.Figure:
    """
    漸進式圖表：僅顯示到目前為止已計算的角度（供 yield 串流動畫使用）。
    與 `build_angle_chart` 相同邏輯，但不顯示原始雜訊曲線以保持即時更新的清晰度。
    """
    return build_angle_chart(
        left_filtered=left_so_far,
        right_filtered=right_so_far,
        sampling_hz=sampling_hz,
        title="膝關節角度曲線（分析中...）",
    )


def build_metrics_html(metrics: Any) -> str:
    """
    將 SessionMetrics 渲染為「金屬質感高光」HTML 數字看板，
    顯示於圖表右側，供面試 Demo 的視覺衝擊力使用。
    """
    def _fmt_deg(v: Optional[float]) -> str:
        return f"{v:.1f}°" if v is not None else "N/A"

    def _fmt_si(v: Optional[float]) -> str:
        return f"{v:+.1f}%" if v is not None else "N/A"

    def _fmt_jerk(v: Optional[float]) -> str:
        return f"{v:.2f}" if v is not None else "N/A"

    compensation_badge = (
        '<span style="color:#FF7043;font-weight:bold;">⚠ 偵測到代償</span>'
        if metrics.compensation_suspected
        else '<span style="color:#66BB6A;font-weight:bold;">✓ 無明顯代償</span>'
    )

    return f"""
<div style="
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
    border-radius: 12px; padding: 16px; color: #e0e0e0;
    font-family: 'Segoe UI', sans-serif; border: 1px solid #0f3460;
">
  <div style="font-size:13px;color:#90CAF9;margin-bottom:12px;letter-spacing:1px;">
    ▌ 量化力學指標
  </div>
  <table style="width:100%;border-collapse:collapse;">
    <tr style="border-bottom:1px solid #0f3460;">
      <td style="padding:6px 4px;color:#B0BEC5;font-size:12px;">左膝 Max ROM</td>
      <td style="padding:6px 4px;color:#EF9A9A;font-size:18px;font-weight:bold;text-align:right;">
        {_fmt_deg(metrics.max_rom_left_deg)}
      </td>
    </tr>
    <tr style="border-bottom:1px solid #0f3460;">
      <td style="padding:6px 4px;color:#B0BEC5;font-size:12px;">右膝 Max ROM</td>
      <td style="padding:6px 4px;color:#90CAF9;font-size:18px;font-weight:bold;text-align:right;">
        {_fmt_deg(metrics.max_rom_right_deg)}
      </td>
    </tr>
    <tr style="border-bottom:1px solid #0f3460;">
      <td style="padding:6px 4px;color:#B0BEC5;font-size:12px;">對稱指數 (SI)</td>
      <td style="padding:6px 4px;color:#CE93D8;font-size:16px;font-weight:bold;text-align:right;">
        {_fmt_si(metrics.symmetry_index_pct)}
      </td>
    </tr>
    <tr style="border-bottom:1px solid #0f3460;">
      <td style="padding:6px 4px;color:#B0BEC5;font-size:12px;">左膝 Jerk Score</td>
      <td style="padding:6px 4px;color:#A5D6A7;font-size:14px;text-align:right;">
        {_fmt_jerk(metrics.jerk_score_left)}
      </td>
    </tr>
    <tr>
      <td style="padding:6px 4px;color:#B0BEC5;font-size:12px;">右膝 Jerk Score</td>
      <td style="padding:6px 4px;color:#A5D6A7;font-size:14px;text-align:right;">
        {_fmt_jerk(metrics.jerk_score_right)}
      </td>
    </tr>
  </table>
  <div style="margin-top:12px;padding-top:10px;border-top:1px solid #0f3460;font-size:13px;">
    {compensation_badge}
  </div>
</div>
"""
