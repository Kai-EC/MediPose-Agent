"""
後端流程橋接模組（Backend Bridge）。

將 Phase 1/2/3 的功能以「可 yield 的生成器」形式包裝，
供 Gradio 前端的事件函式呼叫，實現視覺畫面、角度圖表與
AI 診斷報告的非同步串流更新。

三種模式皆回傳相同的 yield 格式，確保前端事件函式不需判斷模式。
"""
from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Generator, Optional

from ..biomechanics.metrics import SessionMetrics
from ..config import AppConfig, EmbeddingConfig, LLMConfig, RetrievalConfig
from ..llm.client import MockLLMClient, create_llm_client
from ..llm.prompt_builder import _SYSTEM_PROMPT, build_retrieval_query, build_user_prompt
from ..llm.citation_checker import CitationChecker
from ..rag.document_loader import chunk_text
from ..rag.retriever import Retriever
from .demo_data import generate_demo_angle_sequence, generate_demo_session
from ..biomechanics.filtering import butterworth_lowpass_filter
from ..config import FilterConfig

logger = logging.getLogger(__name__)

# yield 格式：(左膝序列, 右膝序列, metrics_or_None, 狀態訊息, HTML指標, 報告文字)
AnalysisYield = tuple[
    list[Optional[float]],
    list[Optional[float]],
    Optional[SessionMetrics],
    str,
    str,
    str,
]

_EMPTY_STATE = ([], [], None, "", "", "")
_CORPUS_FALLBACK = """
前十字韌帶重建術後復健指引。術後目標為恢復膝關節全範圍活動度。
患者膝關節屈曲角度目標為術後第六週達 120 度以上。
若屈曲角度未達 90 度，建議加強主動輔助式屈膝訓練。
左右肢體對稱指數（Robinson SI）正常範圍為 ±15%，超標時需評估代償風險。
運動平滑度（Jerk Score）反映神經肌肉控制品質，越接近 0 代表動作控制越佳。
代償動作偵測：角速度突波超過每秒 300 度視為可能代償。
"""


def _build_retriever(corpus_text: str, config: AppConfig) -> Retriever:
    from ..rag.document_loader import DocumentChunk
    chunks = chunk_text(corpus_text, source="guidelines", config=config.chunking)
    retriever = Retriever(
        embedding_config=config.embedding,
        retrieval_config=config.retrieval,
    )
    retriever.build_index(chunks)
    return retriever


def _stream_report(
    metrics: SessionMetrics,
    retriever: Retriever,
    config: AppConfig,
) -> Generator[str, None, None]:
    """串流輸出 LLM 生成報告，逐字 yield 供前端即時顯示。"""
    llm_client = create_llm_client(config.llm)
    query = build_retrieval_query(metrics)
    retrieved = retriever.query(query)
    user_prompt = build_user_prompt(metrics, retrieved)

    valid_ids = {r.chunk.chunk_id for r in retrieved}
    checker = CitationChecker(config=config.citation)

    accumulated = ""
    for token in llm_client.generate_stream(_SYSTEM_PROMPT, user_prompt):
        accumulated += token
        yield accumulated

    # 最後一次 yield：附加引用驗證統計
    check_result = checker.check(accumulated, valid_ids)
    score_pct = check_result.traceability_score * 100
    footer = (
        f"\n\n---\n*📊 引用可追溯覆蓋率：{score_pct:.1f}%　"
        f"有效引用：{check_result.valid_citations}/{check_result.total_citations}*"
    )
    yield check_result.annotated_report + footer


def run_demo_mode(
    config: AppConfig,
    frame_delay: float = 0.01,
) -> Generator[AnalysisYield, None, None]:
    """
    Demo 模式：使用合成資料，漸進式顯示角度分析過程，再串流輸出 AI 報告。

    Args:
        config: 應用程式設定（LLM backend 應設為 "mock"）。
        frame_delay: 每幀更新間隔（秒），控制動畫速度。

    Yields:
        AnalysisYield 格式的逐步更新資料。
    """
    from .charts import build_metrics_html

    yield [], [], None, "🔄 正在生成展示資料...", "", ""
    time.sleep(0.3)

    # Phase 1 模擬：逐幀顯示骨架偵測進度
    sampling_hz = config.filtering.sampling_hz
    left_raw = generate_demo_angle_sequence(sampling_hz=sampling_hz, max_flexion_deg=85.0, rng_seed=42)
    right_raw = generate_demo_angle_sequence(sampling_hz=sampling_hz, max_flexion_deg=95.0, rng_seed=99)

    total = len(left_raw)
    step = max(1, total // 30)  # 每次更新約 1/30 的資料，避免 yield 過於頻繁

    left_so_far: list[Optional[float]] = []
    right_so_far: list[Optional[float]] = []

    for i in range(0, total, step):
        left_so_far = left_raw[: i + step]
        right_so_far = right_raw[: i + step]
        progress_pct = min(100, int((i + step) / total * 100))
        yield (
            left_so_far, right_so_far, None,
            f"📹 第一階段：關節座標提取中... {progress_pct}%",
            "", "",
        )
        time.sleep(frame_delay)

    # Phase 2：濾波與特徵聚合
    yield left_raw, right_raw, None, "⚙️ 第二階段：生物力學分析中（濾波 + 特徵聚合）...", "", ""
    time.sleep(0.4)

    filter_cfg = FilterConfig(cutoff_hz=6.0, order=2, sampling_hz=sampling_hz)
    left_filtered = butterworth_lowpass_filter(left_raw, filter_cfg)
    right_filtered = butterworth_lowpass_filter(right_raw, filter_cfg)

    from ..biomechanics.metrics import aggregate_session_metrics
    metrics = aggregate_session_metrics(left_filtered, right_filtered, sampling_hz)
    metrics_html = build_metrics_html(metrics)

    yield (
        left_filtered, right_filtered, metrics,
        "✅ 第二階段完成，正在建立 RAG 索引...",
        metrics_html, "",
    )
    time.sleep(0.4)

    # Phase 3：RAG + LLM 串流報告
    retriever = _build_retriever(_CORPUS_FALLBACK, config)

    yield (
        left_filtered, right_filtered, metrics,
        "🤖 第三階段：AI 診斷報告生成中...",
        metrics_html, "",
    )

    report_so_far = ""
    for report_so_far in _stream_report(metrics, retriever, config):
        yield (
            left_filtered, right_filtered, metrics,
            "🤖 AI 診斷報告生成中...",
            metrics_html, report_so_far,
        )

    yield (
        left_filtered, right_filtered, metrics,
        "✅ 分析完成",
        metrics_html, report_so_far,
    )


def run_analysis_from_json(
    analysis_json_path: str,
    corpus_text: str,
    config: AppConfig,
) -> Generator[AnalysisYield, None, None]:
    """
    從第二階段輸出的 JSON 直接進行 Phase 3 分析（跳過 Phase 1/2）。

    Yields:
        AnalysisYield 格式的逐步更新資料。
    """
    from .charts import build_metrics_html

    yield [], [], None, "📂 讀取分析結果中...", "", ""
    time.sleep(0.2)

    try:
        with open(analysis_json_path, encoding="utf-8") as f:
            data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as exc:
        yield [], [], None, f"❌ 讀取失敗：{exc}", "", ""
        return

    m = data.get("metrics", {})
    metrics = SessionMetrics(
        max_rom_left_deg=m.get("max_rom_left_deg"),
        max_rom_right_deg=m.get("max_rom_right_deg"),
        jerk_score_left=m.get("jerk_score_left"),
        jerk_score_right=m.get("jerk_score_right"),
        symmetry_index_pct=m.get("symmetry_index_pct"),
        velocity_anomaly_count_left=m.get("velocity_anomaly_count_left", 0),
        velocity_anomaly_count_right=m.get("velocity_anomaly_count_right", 0),
        compensation_suspected=m.get("compensation_suspected", False),
    )

    left_filtered = [
        f["joints"].get("left_knee", [None])[0] if f.get("person_detected") else None
        for f in data.get("frames", [])
    ]
    right_filtered = [
        f["joints"].get("right_knee", [None])[0] if f.get("person_detected") else None
        for f in data.get("frames", [])
    ]

    metrics_html = build_metrics_html(metrics)
    yield (
        left_filtered, right_filtered, metrics,
        "✅ 力學數據載入完成，正在建立 RAG 索引...",
        metrics_html, "",
    )
    time.sleep(0.3)

    retriever = _build_retriever(corpus_text or _CORPUS_FALLBACK, config)
    yield (
        left_filtered, right_filtered, metrics,
        "🤖 AI 診斷報告生成中...",
        metrics_html, "",
    )

    report_so_far = ""
    for report_so_far in _stream_report(metrics, retriever, config):
        yield (
            left_filtered, right_filtered, metrics,
            "🤖 AI 診斷報告生成中...",
            metrics_html, report_so_far,
        )

    yield (
        left_filtered, right_filtered, metrics,
        "✅ 分析完成",
        metrics_html, report_so_far,
    )
