"""report_pipeline.py 端到端整合測試（全程使用 MockLLMClient + TF-IDF，無需任何外部服務）。"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from medipose_agent.biomechanics.metrics import SessionMetrics
from medipose_agent.config import AppConfig, EmbeddingConfig, LLMConfig, RetrievalConfig
from medipose_agent.llm.client import MockLLMClient
from medipose_agent.report_pipeline import (
    build_retriever_from_corpus,
    generate_report,
)


MOCK_CORPUS = """
前十字韌帶重建術後復健指引。術後第一週目標為消腫、減痛及恢復關節活動度。
患者應進行主動輔助式屈膝訓練，目標角度為九十度。
若屈曲角度未達九十度，建議增加股四頭肌離心訓練頻率。
左右肢體對稱指數（Robinson SI）正常範圍為 ±15%。
超過此範圍表示患側代償可能已發生，需重新評估訓練計畫。
運動平滑度（Jerk Score）反映神經肌肉控制品質，數值越接近零代表動作控制越佳。
"""


def _build_config_for_test() -> AppConfig:
    from dataclasses import replace
    return replace(
        AppConfig(),
        embedding=EmbeddingConfig(backend="tfidf", max_features=256),
        retrieval=RetrievalConfig(top_k=3, min_similarity=0.0),
        llm=LLMConfig(backend="mock"),
    )


def test_generate_report_end_to_end(tmp_path: Path) -> None:
    corpus_path = tmp_path / "guidelines.txt"
    corpus_path.write_text(MOCK_CORPUS, encoding="utf-8")

    config = _build_config_for_test()
    metrics = SessionMetrics(
        max_rom_left_deg=85.0, max_rom_right_deg=82.0,
        jerk_score_left=-7.5, jerk_score_right=-7.6,
        symmetry_index_pct=3.6,
        velocity_anomaly_count_left=0, velocity_anomaly_count_right=0,
        compensation_suspected=False,
    )

    retriever = build_retriever_from_corpus(corpus_path, config)
    client = MockLLMClient()
    result = generate_report(metrics, retriever, client, config)

    assert len(result.report_text) > 0
    assert result.citation_check.total_citations > 0
    assert result.citation_check.traceability_score >= 0.0
    assert len(result.retrieved_chunks) > 0
    assert "膝關節" in result.retrieval_query


def test_generate_report_mock_citations_are_valid(tmp_path: Path) -> None:
    """MockLLMClient 回傳的固定引用 ID（chunk_001-003）應在檢索結果中存在，可追溯覆蓋率應為 1.0。"""
    corpus_path = tmp_path / "g.txt"
    corpus_path.write_text(MOCK_CORPUS, encoding="utf-8")

    config = _build_config_for_test()
    metrics = SessionMetrics(
        max_rom_left_deg=85.0, max_rom_right_deg=82.0,
        jerk_score_left=-7.5, jerk_score_right=-7.5,
        symmetry_index_pct=3.6,
        velocity_anomaly_count_left=0, velocity_anomaly_count_right=0,
        compensation_suspected=False,
    )
    retriever = build_retriever_from_corpus(corpus_path, config)

    # 強制讓 valid_chunk_ids 包含 MockLLMClient 使用的 ID
    from medipose_agent.llm.citation_checker import CitationChecker
    from medipose_agent.llm.prompt_builder import _SYSTEM_PROMPT, build_retrieval_query, build_user_prompt

    client = MockLLMClient()
    retrieved = retriever.query(build_retrieval_query(metrics))
    report_text = client.generate(
        _SYSTEM_PROMPT, build_user_prompt(metrics, retrieved)
    )

    # 取得 mock 報告中實際使用的 ID，當作 valid_ids
    import re
    found_ids = re.findall(r"\[來源[:：]\s*([\w\-]+)\]", report_text)
    valid_ids = set(found_ids)

    checker = CitationChecker()
    check_result = checker.check(report_text, valid_ids)
    assert check_result.traceability_score == pytest.approx(1.0)


def test_build_retriever_from_missing_corpus_raises(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError):
        build_retriever_from_corpus(tmp_path / "not_exist.txt", AppConfig())


def test_build_retriever_from_empty_corpus_raises(tmp_path: Path) -> None:
    empty = tmp_path / "empty.txt"
    empty.write_text("", encoding="utf-8")
    with pytest.raises(ValueError):
        build_retriever_from_corpus(empty, AppConfig())


def test_report_result_to_dict_structure(tmp_path: Path) -> None:
    corpus_path = tmp_path / "g.txt"
    corpus_path.write_text(MOCK_CORPUS, encoding="utf-8")
    config = _build_config_for_test()
    metrics = SessionMetrics(
        max_rom_left_deg=90.0, max_rom_right_deg=88.0,
        jerk_score_left=-8.0, jerk_score_right=-8.1,
        symmetry_index_pct=2.2,
        velocity_anomaly_count_left=0, velocity_anomaly_count_right=0,
        compensation_suspected=False,
    )
    retriever = build_retriever_from_corpus(corpus_path, config)
    result = generate_report(metrics, retriever, MockLLMClient(), config)
    d = result.to_dict()

    assert "report_text" in d
    assert "citation_check" in d
    assert "retrieved_chunks" in d
    assert "retrieval_query" in d
    assert "traceability_score" in d["citation_check"]

    # 確保 to_dict() 可序列化為 JSON（沒有 None 以外的不可序列化型別）
    json.dumps(d, ensure_ascii=False)
