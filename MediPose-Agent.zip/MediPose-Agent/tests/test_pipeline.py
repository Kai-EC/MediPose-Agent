"""pipeline.py 端到端整合測試（合成資料，模擬完美側面視角的對稱屈伸動作）。"""
from __future__ import annotations

import json
import math
from pathlib import Path

import pytest

from medipose_agent.config import AppConfig
from medipose_agent.pipeline import analyze_session


def _build_synthetic_session(tmp_path: Path) -> Path:
    """
    建立合成關節序列 JSON：模擬完美側面視角（phi=0）下，雙腿對稱地
    執行膝關節屈伸（90 度 <-> 180 度），週期 3 秒，取樣率 30Hz。

    幾何設計：knee 固定於原點，hip 固定於 (0, 100)（大腿垂直向上），
    ankle 依目標夾角 theta(t) 沿弧線移動，使得計算出的夾角精確等於 theta(t)，
    且骨段長度恆定（保證視角補償估出 phi=0，不引入額外修正誤差）。
    """
    sampling_hz = 30.0
    duration_sec = 3.0
    hip_len = 100.0
    ankle_len = 80.0

    frames = []
    n_samples = int(duration_sec * sampling_hz)
    for i in range(n_samples):
        t = i / sampling_hz
        theta_deg = 135.0 - 45.0 * math.cos(2 * math.pi * t / 3.0)  # 90 ~ 180 度
        theta_rad = math.radians(theta_deg)
        ankle_x = ankle_len * math.sin(theta_rad)
        ankle_y = -ankle_len * math.cos(theta_rad)

        joints = {
            "left_hip": [0.0, hip_len, 0.95],
            "left_knee": [0.0, 0.0, 0.95],
            "left_ankle": [ankle_x, ankle_y, 0.95],
            "right_hip": [200.0, hip_len, 0.95],
            "right_knee": [200.0, 0.0, 0.95],
            "right_ankle": [200.0 + ankle_x, ankle_y, 0.95],
        }
        frames.append(
            {
                "frame_id": i,
                "timestamp": t,
                "person_detected": True,
                "multi_person_warning": False,
                "joints": joints,
            }
        )

    payload = {
        "frame_count": len(frames),
        "quality_stats": {"total_frames": len(frames), "valid_ratio": 1.0, "multi_person_ratio": 0.0},
        "frames": frames,
    }

    input_path = tmp_path / "synthetic_session.json"
    with input_path.open("w", encoding="utf-8") as f:
        json.dump(payload, f)

    return input_path


def test_analyze_session_end_to_end(tmp_path: Path) -> None:
    input_path = _build_synthetic_session(tmp_path)

    result = analyze_session(input_path, config=AppConfig())

    assert result.frame_count == 90
    assert result.left_knee.reliable_frame_ratio > 0.9
    assert result.right_knee.reliable_frame_ratio > 0.9

    # 完美側面視角、無遮擋情況下，phi 應接近 0
    valid_phi = [p for p in result.left_knee.phi_deg if p is not None]
    assert all(p < 5.0 for p in valid_phi)

    metrics = result.metrics
    assert metrics.max_rom_left_deg == pytest.approx(90.0, abs=5.0)
    assert metrics.max_rom_right_deg == pytest.approx(90.0, abs=5.0)
    assert metrics.symmetry_index_pct == pytest.approx(0.0, abs=2.0)
    assert metrics.jerk_score_left is not None
    assert metrics.compensation_suspected is False


def test_analyze_session_missing_file_raises(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError):
        analyze_session(tmp_path / "does_not_exist.json")
