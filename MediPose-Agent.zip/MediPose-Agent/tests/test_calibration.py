"""calibration.py 單元測試。"""
from __future__ import annotations

import pytest

from medipose_agent.biomechanics.calibration import (
    CalibrationConfig,
    PixelPoint,
    compute_homography,
    pixel_to_cm,
)


def test_homography_round_trip_corners() -> None:
    # 假設畫面中 A4 紙的四角點像素座標（任意縮放+些微透視）
    corners_px = [
        PixelPoint(100, 50),  # 左上
        PixelPoint(400, 60),  # 右上
        PixelPoint(410, 500),  # 右下
        PixelPoint(90, 490),  # 左下
    ]
    config = CalibrationConfig(reference_width_cm=21.0, reference_height_cm=29.7)

    homography = compute_homography(corners_px, config)

    top_left_cm = pixel_to_cm(corners_px[0], homography)
    bottom_right_cm = pixel_to_cm(corners_px[2], homography)

    assert top_left_cm.x == pytest.approx(0.0, abs=1e-3)
    assert top_left_cm.y == pytest.approx(0.0, abs=1e-3)
    assert bottom_right_cm.x == pytest.approx(21.0, abs=1e-3)
    assert bottom_right_cm.y == pytest.approx(29.7, abs=1e-3)


def test_wrong_corner_count_raises() -> None:
    with pytest.raises(ValueError):
        compute_homography([PixelPoint(0, 0), PixelPoint(1, 1)])
