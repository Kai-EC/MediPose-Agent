"""metrics.py 單元測試。"""
from __future__ import annotations

import numpy as np
import pytest

from medipose_agent.biomechanics.metrics import (
    aggregate_session_metrics,
    compute_log_dimensionless_jerk,
    compute_max_rom,
    compute_symmetry_index,
    detect_angular_velocity_anomalies,
)
from medipose_agent.config import MetricsConfig


def test_compute_max_rom_ignores_none() -> None:
    sequence = [10.0, 50.0, 30.0, None, 70.0]
    assert compute_max_rom(sequence) == pytest.approx(60.0)


def test_compute_max_rom_empty_sequence_returns_none() -> None:
    assert compute_max_rom([None, None]) is None


def test_symmetry_index_equal_values_is_zero() -> None:
    assert compute_symmetry_index(50.0, 50.0) == pytest.approx(0.0)


def test_symmetry_index_left_larger_is_positive() -> None:
    # SI = (60-40) / (0.5*(60+40)) * 100 = 20 / 50 * 100 = 40
    assert compute_symmetry_index(60.0, 40.0) == pytest.approx(40.0)


def test_symmetry_index_both_zero_returns_none() -> None:
    assert compute_symmetry_index(0.0, 0.0) is None


def test_jerk_score_smooth_motion_returns_finite_value() -> None:
    sampling_hz = 30.0
    t = np.arange(0, 3.0, 1.0 / sampling_hz)
    smooth_sequence = (90.0 + 45.0 * np.sin(2 * np.pi * 0.3 * t)).tolist()

    score = compute_log_dimensionless_jerk(smooth_sequence, sampling_hz)

    assert score is not None
    assert np.isfinite(score)


def test_jerk_score_too_short_returns_none() -> None:
    assert compute_log_dimensionless_jerk([1.0, 2.0], 30.0) is None


def test_jerk_score_no_movement_returns_none() -> None:
    constant_sequence = [90.0] * 30
    assert compute_log_dimensionless_jerk(constant_sequence, 30.0) is None


def test_jerk_score_jagged_motion_worse_than_smooth() -> None:
    """相同幅度下，含高頻抖動的訊號平滑度分數應低於（更負）平滑訊號。"""
    sampling_hz = 30.0
    t = np.arange(0, 3.0, 1.0 / sampling_hz)
    smooth_sequence = 90.0 + 45.0 * np.sin(2 * np.pi * 0.3 * t)
    jagged_sequence = smooth_sequence + 5.0 * np.sin(2 * np.pi * 8.0 * t)

    smooth_score = compute_log_dimensionless_jerk(smooth_sequence.tolist(), sampling_hz)
    jagged_score = compute_log_dimensionless_jerk(jagged_sequence.tolist(), sampling_hz)

    assert smooth_score is not None and jagged_score is not None
    assert smooth_score > jagged_score


def test_detect_angular_velocity_anomalies_flags_spike() -> None:
    sampling_hz = 30.0
    sequence = [90.0] * 10 + [200.0] + [90.0] * 10  # 單幀劇烈跳動
    count = detect_angular_velocity_anomalies(
        sequence, sampling_hz, MetricsConfig(angular_velocity_anomaly_deg_per_sec=300.0)
    )
    assert count > 0


def test_detect_angular_velocity_anomalies_smooth_motion_no_flag() -> None:
    sampling_hz = 30.0
    t = np.arange(0, 2.0, 1.0 / sampling_hz)
    sequence = (90.0 + 10.0 * np.sin(2 * np.pi * 0.3 * t)).tolist()
    count = detect_angular_velocity_anomalies(
        sequence, sampling_hz, MetricsConfig(angular_velocity_anomaly_deg_per_sec=300.0)
    )
    assert count == 0


def test_aggregate_session_metrics_symmetric_input() -> None:
    sampling_hz = 30.0
    t = np.arange(0, 3.0, 1.0 / sampling_hz)
    sequence = (135.0 - 45.0 * np.cos(2 * np.pi * t / 3.0)).tolist()

    metrics = aggregate_session_metrics(sequence, sequence, sampling_hz)

    assert metrics.max_rom_left_deg == pytest.approx(90.0, abs=1.0)
    assert metrics.max_rom_right_deg == pytest.approx(90.0, abs=1.0)
    assert metrics.symmetry_index_pct == pytest.approx(0.0, abs=1e-6)
    assert metrics.compensation_suspected is False
