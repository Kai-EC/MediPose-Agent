"""llm 模組單元測試：client、prompt_builder、citation_checker。"""
from __future__ import annotations

import pytest

from medipose_agent.biomechanics.metrics import SessionMetrics
from medipose_agent.config import CitationConfig, LLMConfig
from medipose_agent.llm.citation_checker import CitationChecker
from medipose_agent.llm.client import MockLLMClient, create_llm_client
from medipose_agent.llm.prompt_builder import (
    build_retrieval_query,
    build_user_prompt,
)
from medipose_agent.rag.document_loader import DocumentChunk
from medipose_agent.rag.vector_store import RetrievedChunk


def _make_metrics(
    left_rom: float = 85.0, right_rom: float = 82.0,
    compensation: bool = False, si: float = 3.6,
) -> SessionMetrics:
    return SessionMetrics(
        max_rom_left_deg=left_rom, max_rom_right_deg=right_rom,
        jerk_score_left=-7.5, jerk_score_right=-7.5,
        symmetry_index_pct=si,
        velocity_anomaly_count_left=0, velocity_anomaly_count_right=0,
        compensation_suspected=compensation,
    )


def _make_chunks(n: int = 3) -> list[RetrievedChunk]:
    return [
        RetrievedChunk(
            chunk=DocumentChunk(
                chunk_id=f"chunk_{i:03d}", text=f"臨床指引片段 {i}",
                source="guidelines", chunk_index=i,
            ),
            similarity=0.9 - i * 0.1,
        )
        for i in range(1, n + 1)
    ]


# ---------------------------------------------------------------------------
# MockLLMClient
# ---------------------------------------------------------------------------

def test_mock_llm_generate_returns_string() -> None:
    client = MockLLMClient()
    result = client.generate("system prompt", "user prompt")
    assert isinstance(result, str)
    assert len(result) > 0


def test_mock_llm_generate_contains_citations() -> None:
    client = MockLLMClient()
    result = client.generate("", "")
    assert "[來源:" in result


def test_mock_llm_stream_concatenates_to_same_as_generate() -> None:
    client = MockLLMClient()
    streamed = "".join(client.generate_stream("", ""))
    assert streamed == client.generate("", "")


def test_create_llm_client_mock() -> None:
    client = create_llm_client(LLMConfig(backend="mock"))
    assert isinstance(client, MockLLMClient)


def test_create_llm_client_invalid_backend_raises() -> None:
    with pytest.raises(ValueError, match="不支援的 LLM backend"):
        create_llm_client(LLMConfig(backend="unknown"))


# ---------------------------------------------------------------------------
# prompt_builder
# ---------------------------------------------------------------------------

def test_build_user_prompt_contains_metrics() -> None:
    metrics = _make_metrics(left_rom=85.0, right_rom=82.0)
    chunks = _make_chunks()
    prompt = build_user_prompt(metrics, chunks)

    assert "85.00°" in prompt
    assert "82.00°" in prompt
    assert "chunk_001" in prompt


def test_build_user_prompt_none_metrics_shows_placeholder() -> None:
    metrics = SessionMetrics(
        max_rom_left_deg=None, max_rom_right_deg=None,
        jerk_score_left=None, jerk_score_right=None,
        symmetry_index_pct=None,
        velocity_anomaly_count_left=0, velocity_anomaly_count_right=0,
        compensation_suspected=False,
    )
    prompt = build_user_prompt(metrics, [])
    assert "資料不足" in prompt


def test_build_retrieval_query_includes_compensation_keyword() -> None:
    metrics = _make_metrics(compensation=True)
    query = build_retrieval_query(metrics)
    assert "代償" in query


def test_build_retrieval_query_includes_asymmetry_keyword() -> None:
    metrics = _make_metrics(si=30.0)  # 超過 15% 門檻
    query = build_retrieval_query(metrics)
    assert "不對稱" in query


def test_build_retrieval_query_always_includes_base_keyword() -> None:
    metrics = _make_metrics()
    query = build_retrieval_query(metrics)
    assert "膝關節" in query


# ---------------------------------------------------------------------------
# CitationChecker
# ---------------------------------------------------------------------------

def test_citation_checker_valid_citations_score_one() -> None:
    report = "患者恢復良好。[來源: chunk_001]\n建議繼續訓練。[來源: chunk_002]"
    checker = CitationChecker()
    result = checker.check(report, valid_chunk_ids={"chunk_001", "chunk_002"})

    assert result.total_citations == 2
    assert result.valid_citations == 2
    assert result.traceability_score == pytest.approx(1.0)
    assert result.invalid_citation_ids == []


def test_citation_checker_invalid_citation_flagged() -> None:
    report = "患者屈曲角度不足。[來源: chunk_001]\n建議加強訓練。[來源: chunk_999]"
    checker = CitationChecker()
    result = checker.check(report, valid_chunk_ids={"chunk_001"})

    assert result.total_citations == 2
    assert result.valid_citations == 1
    assert result.traceability_score == pytest.approx(0.5)
    assert "chunk_999" in result.invalid_citation_ids
    assert "⚠️ 來源未驗證: chunk_999" in result.annotated_report


def test_citation_checker_no_citations_score_zero() -> None:
    report = "患者情況良好，建議繼續訓練。"
    checker = CitationChecker()
    result = checker.check(report, valid_chunk_ids={"chunk_001"})

    assert result.total_citations == 0
    assert result.traceability_score == pytest.approx(0.0)


def test_citation_checker_uncited_clinical_sentence_detected() -> None:
    report = "患者左膝屈曲角度不足，建議加強股四頭肌訓練。"  # 有臨床關鍵詞但無引用
    checker = CitationChecker()
    result = checker.check(report, valid_chunk_ids=set())

    assert len(result.uncited_sentences) > 0


def test_citation_checker_custom_pattern() -> None:
    report = "患者恢復良好。[ref: doc_001]"
    checker = CitationChecker(config=CitationConfig(citation_pattern=r"\[ref:\s*([\w\-]+)\]"))
    result = checker.check(report, valid_chunk_ids={"doc_001"})

    assert result.total_citations == 1
    assert result.traceability_score == pytest.approx(1.0)
