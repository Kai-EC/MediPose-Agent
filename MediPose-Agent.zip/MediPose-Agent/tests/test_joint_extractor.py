"""LowerBodyJointExtractor 單元測試。"""
from __future__ import annotations

import pytest

from medipose_agent.config import LOWER_BODY_KEYPOINTS
from medipose_agent.joint_extractor import LowerBodyJointExtractor
from tests.fakes import (
    make_multi_person_result,
    make_no_person_result,
    make_single_person_result,
)


def test_extract_single_person_all_joints_valid() -> None:
    extractor = LowerBodyJointExtractor(confidence_threshold=0.5)
    result = make_single_person_result(confidence=0.9)

    joint_frame = extractor.extract(frame_id=0, timestamp=0.0, yolo_result=result)

    assert joint_frame.person_detected is True
    assert joint_frame.multi_person_warning is False
    assert set(joint_frame.joints.keys()) == set(LOWER_BODY_KEYPOINTS.keys())

    # 驗證座標對應到正確的關鍵點索引（座標值 = 索引，依 fakes.py 建構規則）
    left_hip_index = LOWER_BODY_KEYPOINTS["left_hip"]
    assert joint_frame.joints["left_hip"].x == pytest.approx(float(left_hip_index))
    assert joint_frame.joints["left_hip"].confidence == pytest.approx(0.9)


def test_extract_filters_low_confidence_joints() -> None:
    extractor = LowerBodyJointExtractor(confidence_threshold=0.6)
    result = make_single_person_result(confidence=0.4)  # 全部低於門檻

    joint_frame = extractor.extract(frame_id=1, timestamp=0.1, yolo_result=result)

    assert joint_frame.person_detected is True
    assert joint_frame.joints == {}  # 所有關節皆因信心不足被捨棄


def test_extract_no_person_detected() -> None:
    extractor = LowerBodyJointExtractor()
    result = make_no_person_result()

    joint_frame = extractor.extract(frame_id=2, timestamp=0.2, yolo_result=result)

    assert joint_frame.person_detected is False
    assert joint_frame.multi_person_warning is False
    assert joint_frame.joints == {}


def test_extract_selects_highest_confidence_person_when_multiple() -> None:
    extractor = LowerBodyJointExtractor(confidence_threshold=0.5)
    result = make_multi_person_result()

    joint_frame = extractor.extract(frame_id=3, timestamp=0.3, yolo_result=result)

    assert joint_frame.person_detected is True
    assert joint_frame.multi_person_warning is True
    # person 1（高信心，座標 offset +100）應被選中，而非低信心的 person 0
    left_hip_index = LOWER_BODY_KEYPOINTS["left_hip"]
    assert joint_frame.joints["left_hip"].x == pytest.approx(float(left_hip_index) + 100)
    assert joint_frame.joints["left_hip"].confidence == pytest.approx(0.9)


@pytest.mark.parametrize("invalid_threshold", [-0.1, 1.1])
def test_invalid_confidence_threshold_raises(invalid_threshold: float) -> None:
    with pytest.raises(ValueError):
        LowerBodyJointExtractor(confidence_threshold=invalid_threshold)
