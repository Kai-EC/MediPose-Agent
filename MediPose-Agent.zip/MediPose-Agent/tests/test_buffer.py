"""JointSequenceBuffer 單元測試。"""
from __future__ import annotations

import json

import pytest

from medipose_agent.buffer import JointSequenceBuffer
from medipose_agent.config import BufferConfig
from medipose_agent.joint_extractor import JointFrame, JointPoint


def _make_joint_frame(frame_id: int, person_detected: bool = True) -> JointFrame:
    joints = (
        {"left_knee": JointPoint(x=1.0, y=2.0, confidence=0.9)}
        if person_detected
        else {}
    )
    return JointFrame(
        frame_id=frame_id,
        timestamp=float(frame_id),
        joints=joints,
        person_detected=person_detected,
    )


def test_append_and_get_all() -> None:
    buffer = JointSequenceBuffer(BufferConfig(max_frames=10))
    buffer.append(_make_joint_frame(0))
    buffer.append(_make_joint_frame(1))

    frames = buffer.get_all()
    assert len(frames) == 2
    assert len(buffer) == 2


def test_export_empty_buffer_raises(tmp_path: object) -> None:
    buffer = JointSequenceBuffer(BufferConfig(export_dir=tmp_path))  # type: ignore[arg-type]
    with pytest.raises(ValueError):
        buffer.export("empty.json")


def test_export_writes_valid_json(tmp_path: object) -> None:
    buffer = JointSequenceBuffer(BufferConfig(export_dir=tmp_path))  # type: ignore[arg-type]
    buffer.append(_make_joint_frame(0, person_detected=True))
    buffer.append(_make_joint_frame(1, person_detected=False))

    output_path = buffer.export("session.json")
    assert output_path.exists()

    with output_path.open(encoding="utf-8") as f:
        payload = json.load(f)

    assert payload["frame_count"] == 2
    assert payload["quality_stats"]["valid_ratio"] == pytest.approx(0.5)
    assert payload["frames"][0]["frame_id"] == 0
    assert "left_knee" in payload["frames"][0]["joints"]


def test_buffer_overflow_drops_oldest() -> None:
    buffer = JointSequenceBuffer(BufferConfig(max_frames=2))
    buffer.append(_make_joint_frame(0))
    buffer.append(_make_joint_frame(1))
    buffer.append(_make_joint_frame(2))  # 應擠掉 frame_id=0

    frames = buffer.get_all()
    assert len(frames) == 2
    assert [f.frame_id for f in frames] == [1, 2]


def test_stats_on_empty_buffer() -> None:
    buffer = JointSequenceBuffer()
    assert buffer.stats == {
        "total_frames": 0,
        "valid_ratio": 0.0,
        "multi_person_ratio": 0.0,
    }
