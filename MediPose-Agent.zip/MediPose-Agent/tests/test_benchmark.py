"""benchmark.py 單元測試：驗證基準測試模組的邏輯正確性。"""
from __future__ import annotations

import pytest

from medipose_agent.benchmark import (
    BenchmarkReport,
    _generate_synthetic_frames,
    _time_fn,
    run_phase2_benchmarks,
    run_phase3_benchmarks,
    run_full_pipeline_benchmark,
)


def test_generate_synthetic_frames_count() -> None:
    frames = _generate_synthetic_frames(n=90, sampling_hz=30.0)
    assert len(frames) == 90


def test_generate_synthetic_frames_all_have_six_joints() -> None:
    frames = _generate_synthetic_frames(n=10)
    expected_joints = {
        "left_hip", "left_knee", "left_ankle",
        "right_hip", "right_knee", "right_ankle",
    }
    for frame in frames:
        assert set(frame.joints.keys()) == expected_joints


def test_time_fn_returns_four_floats() -> None:
    result = _time_fn(lambda: sum(range(100)), repeat=5)
    assert len(result) == 4
    assert all(isinstance(v, float) for v in result)


def test_time_fn_median_between_min_and_max() -> None:
    med, mn, mx, _ = _time_fn(lambda: sum(range(100)), repeat=10)
    assert mn <= med <= mx


def test_run_phase2_benchmarks_populates_report() -> None:
    report = BenchmarkReport(timestamp="test", system_note="test")
    run_phase2_benchmarks(report, n_frames=30)
    assert len(report.items) == 5
    for item in report.items:
        assert item.median >= 0
        assert item.min_val <= item.median


def test_run_phase3_benchmarks_populates_report() -> None:
    report = BenchmarkReport(timestamp="test", system_note="test")
    run_phase3_benchmarks(report, with_ollama=False)
    assert len(report.items) == 3


def test_run_full_pipeline_benchmark_populates_report() -> None:
    report = BenchmarkReport(timestamp="test", system_note="test")
    run_full_pipeline_benchmark(report)
    assert len(report.items) == 1
    assert "端對端" in report.items[0].name


def test_benchmark_report_to_dict_serializable() -> None:
    import json
    report = BenchmarkReport(timestamp="2026-01-01", system_note="test env")
    run_phase2_benchmarks(report, n_frames=30)
    d = report.to_dict()
    json.dumps(d)  # 確保可 JSON 序列化


def test_benchmark_report_print_table_no_exception(capsys) -> None:
    report = BenchmarkReport(timestamp="2026-01-01", system_note="test")
    run_phase2_benchmarks(report, n_frames=30)
    report.print_table()
    captured = capsys.readouterr()
    assert "MediPose-Agent" in captured.out
    assert "ms" in captured.out
