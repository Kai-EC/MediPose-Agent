"""correction.py 單元測試。"""
from __future__ import annotations

import math

import pytest

from medipose_agent.biomechanics.correction import (
    correct_frame_angle,
    estimate_reference_lengths,
)
from medipose_agent.config import CorrectionConfig
from medipose_agent.joint_extractor import JointFrame, JointPoint


def _make_frame(frame_id: int, hip_len: float, ankle_len: float) -> JointFrame:
    """建立 vertex 固定於原點、骨段長度可控的合成影格（夾角恆為 90 度）。"""
    return JointFrame(
        frame_id=frame_id, timestamp=frame_id / 30.0,
        joints={
            "left_hip": JointPoint(hip_len, 0, 0.9),
            "left_knee": JointPoint(0, 0, 0.9),
            "left_ankle": JointPoint(0, -ankle_len, 0.9),
        },
        person_detected=True,
    )


def test_estimate_reference_lengths_uses_median() -> None:
    frames = [_make_frame(i, hip_len=100.0, ankle_len=80.0) for i in range(5)]

    result = estimate_reference_lengths(frames, "left_hip", "left_knee", "left_ankle", 5)

    assert result is not None
    ref_hip, ref_ankle = result
    assert ref_hip == pytest.approx(100.0)
    assert ref_ankle == pytest.approx(80.0)


def test_estimate_reference_lengths_returns_none_when_no_data() -> None:
    frames = [
        JointFrame(frame_id=0, timestamp=0.0, joints={}, person_detected=False)
    ]
    result = estimate_reference_lengths(frames, "left_hip", "left_knee", "left_ankle", 5)
    assert result is None


def test_zero_phi_yields_unchanged_angle() -> None:
    """觀測骨段長度與基準長度相同時，phi=0，修正後角度應等於原始角度。"""
    frame = _make_frame(0, hip_len=100.0, ankle_len=80.0)
    proximal = frame.joints["left_hip"]
    vertex = frame.joints["left_knee"]
    distal = frame.joints["left_ankle"]
    theta_raw = 90.0  # 由 _make_frame 的幾何配置可推得夾角為 90 度

    result = correct_frame_angle(
        theta_raw, proximal, vertex, distal, reference_lengths=(100.0, 80.0)
    )

    assert result.is_reliable is True
    assert result.phi_deg == pytest.approx(0.0, abs=1e-4)
    assert result.theta_corrected_deg == pytest.approx(theta_raw, abs=1e-4)
    assert result.confidence_margin_deg == pytest.approx(0.0, abs=1e-4)
    assert result.dual_segment_disagreement_flag is False


def test_uniform_foreshortening_applies_documented_formula() -> None:
    """雙骨段等比例縮短（phi=30度）時，驗證修正公式與文件描述一致。"""
    phi_true_deg = 30.0
    ratio = math.cos(math.radians(phi_true_deg))
    ref_hip, ref_ankle = 100.0, 80.0

    frame = _make_frame(0, hip_len=ref_hip * ratio, ankle_len=ref_ankle * ratio)
    proximal = frame.joints["left_hip"]
    vertex = frame.joints["left_knee"]
    distal = frame.joints["left_ankle"]
    theta_raw = 90.0

    result = correct_frame_angle(
        theta_raw, proximal, vertex, distal, reference_lengths=(ref_hip, ref_ankle)
    )

    expected_deviation_corrected = (180.0 - theta_raw) / ratio
    expected_theta_corrected = 180.0 - expected_deviation_corrected

    assert result.is_reliable is True
    assert result.phi_deg == pytest.approx(phi_true_deg, abs=1e-3)
    assert result.theta_corrected_deg == pytest.approx(expected_theta_corrected, abs=1e-3)
    assert result.dual_segment_disagreement_flag is False


def test_phi_exceeding_threshold_marked_unreliable() -> None:
    ref_hip, ref_ankle = 100.0, 80.0
    # ratio=0.1 -> phi = arccos(0.1) ≈ 84.3 度，超過預設門檻 60 度
    frame = _make_frame(0, hip_len=ref_hip * 0.1, ankle_len=ref_ankle * 0.1)
    proximal = frame.joints["left_hip"]
    vertex = frame.joints["left_knee"]
    distal = frame.joints["left_ankle"]

    result = correct_frame_angle(
        90.0, proximal, vertex, distal, reference_lengths=(ref_hip, ref_ankle)
    )

    assert result.is_reliable is False
    assert result.theta_corrected_deg is None
    assert result.phi_deg is not None and result.phi_deg > 60.0


def test_dual_segment_disagreement_flagged() -> None:
    """近端骨段未縮短、遠端骨段大幅縮短時，應標記單軸旋轉假設可能失效。"""
    ref_hip, ref_ankle = 100.0, 80.0
    frame = _make_frame(0, hip_len=ref_hip * 1.0, ankle_len=ref_ankle * 0.5)
    proximal = frame.joints["left_hip"]
    vertex = frame.joints["left_knee"]
    distal = frame.joints["left_ankle"]

    result = correct_frame_angle(
        90.0, proximal, vertex, distal,
        reference_lengths=(ref_hip, ref_ankle),
        config=CorrectionConfig(dual_segment_disagreement_deg=20.0),
    )

    assert result.dual_segment_disagreement_flag is True
