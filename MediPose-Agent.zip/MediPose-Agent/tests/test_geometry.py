"""geometry.py 單元測試。"""
from __future__ import annotations

import pytest

from medipose_agent.biomechanics.geometry import (
    JointTriplet,
    compute_angle_sequence,
    compute_joint_angle_deg,
)
from medipose_agent.joint_extractor import JointFrame, JointPoint


def test_straight_line_yields_180_degrees() -> None:
    # A--B--C 共線排列，夾角應為 180 度
    a = JointPoint(x=0, y=0, confidence=0.9)
    b = JointPoint(x=1, y=0, confidence=0.9)
    c = JointPoint(x=2, y=0, confidence=0.9)

    angle = compute_joint_angle_deg(a, b, c)

    assert angle == pytest.approx(180.0, abs=1e-6)


def test_right_angle_yields_90_degrees() -> None:
    a = JointPoint(x=0, y=1, confidence=0.9)
    b = JointPoint(x=0, y=0, confidence=0.9)
    c = JointPoint(x=1, y=0, confidence=0.9)

    angle = compute_joint_angle_deg(a, b, c)

    assert angle == pytest.approx(90.0, abs=1e-6)


def test_degenerate_zero_length_vector_returns_none() -> None:
    a = JointPoint(x=0, y=0, confidence=0.9)
    b = JointPoint(x=0, y=0, confidence=0.9)  # 與 a 重合
    c = JointPoint(x=1, y=0, confidence=0.9)

    assert compute_joint_angle_deg(a, b, c) is None


def test_angle_independent_of_scale() -> None:
    """角度計算應與向量絕對長度無關（純方向關係）。"""
    a1 = JointPoint(x=0, y=1, confidence=0.9)
    b1 = JointPoint(x=0, y=0, confidence=0.9)
    c1 = JointPoint(x=1, y=0, confidence=0.9)

    a2 = JointPoint(x=0, y=100, confidence=0.9)
    b2 = JointPoint(x=0, y=0, confidence=0.9)
    c2 = JointPoint(x=50, y=0, confidence=0.9)

    assert compute_joint_angle_deg(a1, b1, c1) == pytest.approx(
        compute_joint_angle_deg(a2, b2, c2), abs=1e-6
    )


def test_compute_angle_sequence_handles_missing_joints() -> None:
    triplet = JointTriplet("left_hip", "left_knee", "left_ankle")

    frame_complete = JointFrame(
        frame_id=0, timestamp=0.0,
        joints={
            "left_hip": JointPoint(0, 1, 0.9),
            "left_knee": JointPoint(0, 0, 0.9),
            "left_ankle": JointPoint(1, 0, 0.9),
        },
        person_detected=True,
    )
    frame_missing_ankle = JointFrame(
        frame_id=1, timestamp=0.033,
        joints={
            "left_hip": JointPoint(0, 1, 0.9),
            "left_knee": JointPoint(0, 0, 0.9),
        },
        person_detected=True,
    )

    angles = compute_angle_sequence([frame_complete, frame_missing_ankle], triplet)

    assert angles[0] == pytest.approx(90.0, abs=1e-6)
    assert angles[1] is None
