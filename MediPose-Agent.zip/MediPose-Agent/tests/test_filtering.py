"""filtering.py 單元測試。"""
from __future__ import annotations

import numpy as np
import pytest

from medipose_agent.biomechanics.filtering import (
    butterworth_lowpass_filter,
    interpolate_missing_values,
)
from medipose_agent.config import FilterConfig


def test_interpolate_short_gap() -> None:
    sequence = [1.0, 2.0, None, 4.0, 5.0]
    result = interpolate_missing_values(sequence, max_gap=5)
    assert result == pytest.approx([1.0, 2.0, 3.0, 4.0, 5.0])


def test_interpolate_long_gap_not_filled() -> None:
    sequence = [1.0, None, None, None, None, None, 6.0]
    result = interpolate_missing_values(sequence, max_gap=2)
    assert result[1:6] == [None, None, None, None, None]


def test_interpolate_edge_gap_not_filled() -> None:
    # 序列開頭缺值，左側無已知值可供插補
    sequence = [None, None, 3.0, 4.0]
    result = interpolate_missing_values(sequence, max_gap=5)
    assert result[0] is None and result[1] is None


def test_filter_reduces_high_frequency_noise() -> None:
    sampling_hz = 30.0
    duration_sec = 5.0
    t = np.arange(0, duration_sec, 1.0 / sampling_hz)

    clean_signal = 10.0 * np.sin(2 * np.pi * 0.5 * t)  # 0.5Hz 低頻訊號（真實動作）
    noise = 3.0 * np.sin(2 * np.pi * 10.0 * t)  # 10Hz 高頻雜訊（遠超過 6Hz 截止頻率）
    noisy_signal = (clean_signal + noise).tolist()

    config = FilterConfig(cutoff_hz=6.0, order=2, sampling_hz=sampling_hz)
    filtered = butterworth_lowpass_filter(noisy_signal, config)

    filtered_arr = np.array(filtered, dtype=float)
    error_before = np.sqrt(np.mean((np.array(noisy_signal) - clean_signal) ** 2))
    error_after = np.sqrt(np.mean((filtered_arr - clean_signal) ** 2))

    assert error_after < error_before * 0.5  # 濾波後應大幅貼近真實低頻訊號


def test_invalid_cutoff_raises() -> None:
    config = FilterConfig(cutoff_hz=20.0, sampling_hz=30.0)  # cutoff > 奈奎斯特頻率(15Hz)
    with pytest.raises(ValueError):
        butterworth_lowpass_filter([1.0] * 50, config)


def test_filter_preserves_sequence_length_with_gap() -> None:
    sampling_hz = 30.0
    t = np.arange(0, 2.0, 1.0 / sampling_hz)
    signal = (5.0 * np.sin(2 * np.pi * 0.5 * t)).tolist()
    signal_with_gap = signal[:20] + [None] * 3 + signal[23:]

    config = FilterConfig(cutoff_hz=6.0, sampling_hz=sampling_hz, max_interpolation_gap=5)
    filtered = butterworth_lowpass_filter(signal_with_gap, config)

    assert len(filtered) == len(signal_with_gap)
