"""embeddings.py + vector_store.py + retriever.py 單元測試。"""
from __future__ import annotations

import numpy as np
import pytest

from medipose_agent.config import EmbeddingConfig, RetrievalConfig
from medipose_agent.rag.document_loader import DocumentChunk
from medipose_agent.rag.embeddings import TfidfEmbedding, create_embedding_model
from medipose_agent.rag.retriever import Retriever
from medipose_agent.rag.vector_store import FaissVectorStore


# ---------------------------------------------------------------------------
# TfidfEmbedding 測試
# ---------------------------------------------------------------------------

def test_tfidf_fit_and_embed_shape() -> None:
    corpus = ["膝關節屈曲角度訓練", "前十字韌帶重建術後復健", "對稱步態訓練"]
    model = TfidfEmbedding(max_features=128)
    model.fit(corpus)
    vectors = model.embed(corpus)
    assert vectors.shape == (3, model.dimension)
    assert vectors.dtype == np.float32


def test_tfidf_embed_before_fit_raises() -> None:
    model = TfidfEmbedding()
    with pytest.raises(RuntimeError, match="尚未呼叫 fit"):
        model.embed(["test"])


def test_tfidf_fit_empty_corpus_raises() -> None:
    with pytest.raises(ValueError):
        TfidfEmbedding().fit([])


def test_create_embedding_model_tfidf() -> None:
    model = create_embedding_model(EmbeddingConfig(backend="tfidf"))
    assert isinstance(model, TfidfEmbedding)


def test_create_embedding_model_invalid_backend_raises() -> None:
    with pytest.raises(ValueError, match="不支援的 embedding backend"):
        create_embedding_model(EmbeddingConfig(backend="unknown"))


# ---------------------------------------------------------------------------
# FaissVectorStore 測試
# ---------------------------------------------------------------------------

def _make_chunks(n: int) -> list[DocumentChunk]:
    return [
        DocumentChunk(chunk_id=f"c{i}", text=f"片段{i}", source="test", chunk_index=i)
        for i in range(n)
    ]


def test_vector_store_add_and_search() -> None:
    store = FaissVectorStore(dimension=4)
    vectors = np.eye(4, dtype=np.float32)  # 4 個正交單位向量
    chunks = _make_chunks(4)
    store.add(vectors, chunks)

    results = store.search(np.array([1, 0, 0, 0], dtype=np.float32), top_k=1)
    assert len(results) == 1
    assert results[0].chunk.chunk_id == "c0"
    assert results[0].similarity == pytest.approx(1.0, abs=1e-4)


def test_vector_store_empty_returns_empty_list() -> None:
    store = FaissVectorStore(dimension=4)
    results = store.search(np.ones(4, dtype=np.float32), top_k=3)
    assert results == []


def test_vector_store_invalid_dimension_raises() -> None:
    with pytest.raises(ValueError):
        FaissVectorStore(dimension=0)


def test_vector_store_dimension_mismatch_raises() -> None:
    store = FaissVectorStore(dimension=4)
    wrong_vectors = np.ones((2, 8), dtype=np.float32)
    with pytest.raises(ValueError, match="向量維度不符"):
        store.add(wrong_vectors, _make_chunks(2))


def test_vector_store_count_length_mismatch_raises() -> None:
    store = FaissVectorStore(dimension=4)
    vectors = np.ones((3, 4), dtype=np.float32)
    with pytest.raises(ValueError, match="不一致"):
        store.add(vectors, _make_chunks(2))


def test_vector_store_len() -> None:
    store = FaissVectorStore(dimension=4)
    store.add(np.ones((3, 4), dtype=np.float32), _make_chunks(3))
    assert len(store) == 3


# ---------------------------------------------------------------------------
# Retriever 整合測試（TF-IDF + FAISS，純本機可跑）
# ---------------------------------------------------------------------------

def test_retriever_returns_relevant_chunk() -> None:
    corpus = [
        DocumentChunk(chunk_id="ck_knee", text="膝關節屈曲復健角度訓練建議", source="doc", chunk_index=0),
        DocumentChunk(chunk_id="ck_balance", text="平衡訓練與核心肌群強化", source="doc", chunk_index=1),
        DocumentChunk(chunk_id="ck_acl", text="前十字韌帶術後疼痛控制與腫脹處理", source="doc", chunk_index=2),
    ]
    retriever = Retriever(
        embedding_config=EmbeddingConfig(backend="tfidf", max_features=256),
        retrieval_config=RetrievalConfig(top_k=1, min_similarity=0.0),
    )
    retriever.build_index(corpus)

    results = retriever.query("膝關節屈曲角度不足")
    assert len(results) == 1
    assert results[0].chunk.chunk_id == "ck_knee"


def test_retriever_before_build_index_raises() -> None:
    retriever = Retriever(
        embedding_config=EmbeddingConfig(backend="tfidf", max_features=128)
    )
    with pytest.raises(RuntimeError, match="build_index"):
        retriever.query("test")


def test_retriever_min_similarity_filter() -> None:
    corpus = [
        DocumentChunk(chunk_id="ck0", text="膝關節復健", source="d", chunk_index=0),
    ]
    retriever = Retriever(
        embedding_config=EmbeddingConfig(backend="tfidf", max_features=128),
        retrieval_config=RetrievalConfig(top_k=3, min_similarity=1.0),  # 門檻設為 1.0，幾乎不可能通過
    )
    retriever.build_index(corpus)
    results = retriever.query("完全不相關的查詢文字")
    assert results == []


def test_retriever_empty_corpus_raises() -> None:
    retriever = Retriever(
        embedding_config=EmbeddingConfig(backend="tfidf", max_features=128)
    )
    with pytest.raises(ValueError):
        retriever.build_index([])
