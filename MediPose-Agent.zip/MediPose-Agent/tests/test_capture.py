"""VideoStreamReader 輸入驗證邏輯單元測試（不涉及實際攝影機/影片讀取）。"""
from __future__ import annotations

import pytest

from medipose_agent.capture import VideoStreamReader


def test_negative_webcam_index_raises() -> None:
    with pytest.raises(ValueError, match="不可為負數"):
        VideoStreamReader(source=-1)


def test_nonexistent_file_path_raises() -> None:
    with pytest.raises(ValueError, match="找不到影片檔案"):
        VideoStreamReader(source="this_file_does_not_exist_12345.mp4")


def test_valid_webcam_index_accepted() -> None:
    # 僅驗證來源通過驗證階段，不呼叫 start()（不需要實際裝置）
    reader = VideoStreamReader(source=0)
    assert reader._source == 0  # noqa: SLF001 -- 測試內部狀態屬合理使用
