"""第四階段 UI 模組單元測試（不啟動 Gradio server，純邏輯驗證）。"""
from __future__ import annotations

import pytest

from medipose_agent.biomechanics.metrics import SessionMetrics
from medipose_agent.ui.charts import build_angle_chart, build_metrics_html
from medipose_agent.ui.demo_data import generate_demo_angle_sequence, generate_demo_session


# ---------------------------------------------------------------------------
# demo_data.py
# ---------------------------------------------------------------------------

def test_demo_angle_sequence_length() -> None:
    sampling_hz = 30.0
    duration_sec = 6.0
    seq = generate_demo_angle_sequence(sampling_hz=sampling_hz, duration_sec=duration_sec)
    assert len(seq) == int(duration_sec * sampling_hz)


def test_demo_angle_sequence_within_valid_range() -> None:
    seq = generate_demo_angle_sequence(max_flexion_deg=90.0)
    valid = [v for v in seq if v is not None]
    # 允許雜訊導致些微超出，但大部分應在 85~185 度內
    assert all(70.0 <= v <= 200.0 for v in valid)


def test_demo_angle_sequence_reproducible() -> None:
    """相同 rng_seed 應產生完全相同的序列。"""
    seq1 = generate_demo_angle_sequence(rng_seed=42)
    seq2 = generate_demo_angle_sequence(rng_seed=42)
    assert seq1 == seq2


def test_demo_angle_sequence_different_seeds_differ() -> None:
    seq1 = generate_demo_angle_sequence(rng_seed=42)
    seq2 = generate_demo_angle_sequence(rng_seed=99)
    assert seq1 != seq2


def test_generate_demo_session_returns_correct_types() -> None:
    left, right, metrics = generate_demo_session()
    assert isinstance(left, list)
    assert isinstance(right, list)
    assert isinstance(metrics, SessionMetrics)
    assert len(left) == len(right)


def test_generate_demo_session_left_rom_less_than_right() -> None:
    """患側（左膝）最大屈曲應小於健側（右膝）。"""
    _, _, metrics = generate_demo_session()
    assert metrics.max_rom_left_deg is not None
    assert metrics.max_rom_right_deg is not None
    assert metrics.max_rom_left_deg < metrics.max_rom_right_deg


# ---------------------------------------------------------------------------
# charts.py
# ---------------------------------------------------------------------------

def test_build_angle_chart_returns_figure() -> None:
    import plotly.graph_objects as go
    left = [180.0, 150.0, 120.0, 150.0, 180.0]
    right = [180.0, 145.0, 115.0, 145.0, 180.0]
    fig = build_angle_chart(left, right)
    assert isinstance(fig, go.Figure)


def test_build_angle_chart_with_raw_has_four_traces() -> None:
    import plotly.graph_objects as go
    seq = [180.0, 150.0, 120.0]
    fig = build_angle_chart(seq, seq, left_raw=seq, right_raw=seq)
    assert len(fig.data) == 4  # 左右各有原始 + 濾波 = 4 條線


def test_build_angle_chart_empty_input() -> None:
    """空輸入不應拋出例外。"""
    import plotly.graph_objects as go
    fig = build_angle_chart([], [])
    assert isinstance(fig, go.Figure)


def test_build_metrics_html_contains_rom_values() -> None:
    metrics = SessionMetrics(
        max_rom_left_deg=85.0, max_rom_right_deg=95.0,
        jerk_score_left=-7.5, jerk_score_right=-7.2,
        symmetry_index_pct=10.5,
        velocity_anomaly_count_left=0, velocity_anomaly_count_right=0,
        compensation_suspected=False,
    )
    html = build_metrics_html(metrics)
    assert "85.0°" in html
    assert "95.0°" in html
    assert "+10.5%" in html
    assert "✓ 無明顯代償" in html


def test_build_metrics_html_shows_compensation_warning() -> None:
    metrics = SessionMetrics(
        max_rom_left_deg=70.0, max_rom_right_deg=90.0,
        jerk_score_left=-12.0, jerk_score_right=-8.0,
        symmetry_index_pct=25.0,
        velocity_anomaly_count_left=3, velocity_anomaly_count_right=0,
        compensation_suspected=True,
    )
    html = build_metrics_html(metrics)
    assert "⚠" in html
    assert "代償" in html


def test_build_metrics_html_none_values_show_na() -> None:
    metrics = SessionMetrics(
        max_rom_left_deg=None, max_rom_right_deg=None,
        jerk_score_left=None, jerk_score_right=None,
        symmetry_index_pct=None,
        velocity_anomaly_count_left=0, velocity_anomaly_count_right=0,
        compensation_suspected=False,
    )
    html = build_metrics_html(metrics)
    assert "N/A" in html


# ---------------------------------------------------------------------------
# backend.py (demo 模式邏輯驗證，不啟動任何服務)
# ---------------------------------------------------------------------------

def test_demo_mode_yields_nonempty_sequences() -> None:
    from dataclasses import replace
    from medipose_agent.config import AppConfig, EmbeddingConfig, LLMConfig, RetrievalConfig
    from medipose_agent.ui.backend import run_demo_mode

    config = replace(
        AppConfig(),
        embedding=EmbeddingConfig(backend="tfidf", max_features=256),
        retrieval=RetrievalConfig(top_k=2, min_similarity=0.0),
        llm=LLMConfig(backend="mock"),
    )

    results = list(run_demo_mode(config, frame_delay=0.0))
    assert len(results) > 3  # 應有多次 yield

    final = results[-1]
    left_seq, right_seq, metrics, status, html, report = final

    assert len(left_seq) > 0
    assert len(right_seq) > 0
    assert metrics is not None
    assert "完成" in status
    assert len(report) > 0


def test_demo_mode_final_report_contains_citation() -> None:
    from dataclasses import replace
    from medipose_agent.config import AppConfig, EmbeddingConfig, LLMConfig, RetrievalConfig
    from medipose_agent.ui.backend import run_demo_mode

    config = replace(
        AppConfig(),
        embedding=EmbeddingConfig(backend="tfidf", max_features=256),
        retrieval=RetrievalConfig(top_k=2, min_similarity=0.0),
        llm=LLMConfig(backend="mock"),
    )

    final = list(run_demo_mode(config, frame_delay=0.0))[-1]
    _, _, _, _, _, report = final
    assert "引用可追溯覆蓋率" in report


# ---------------------------------------------------------------------------
# app.py (Gradio Blocks 建立測試，不啟動 server)
# ---------------------------------------------------------------------------

def test_build_app_creates_blocks() -> None:
    import gradio as gr
    from medipose_agent.app import build_app

    app = build_app(default_mode="demo")
    assert isinstance(app, gr.Blocks)
