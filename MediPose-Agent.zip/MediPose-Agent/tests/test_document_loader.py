"""document_loader.py 單元測試。"""
from __future__ import annotations

import pytest

from medipose_agent.config import ChunkingConfig
from medipose_agent.rag.document_loader import chunk_text


def test_empty_text_returns_empty_list() -> None:
    assert chunk_text("", source="test") == []
    assert chunk_text("   ", source="test") == []


def test_short_text_yields_single_chunk() -> None:
    text = "膝關節活動度訓練建議每日執行。"
    chunks = chunk_text(text, source="test", config=ChunkingConfig(chunk_size_chars=500))
    assert len(chunks) == 1
    assert chunks[0].source == "test"
    assert chunks[0].chunk_index == 0


def test_long_text_splits_into_multiple_chunks() -> None:
    # 製造超過 50 字元的文字，確保會被切成多個片段
    sentence = "患者膝關節屈曲角度訓練應循序漸進。"
    text = sentence * 20  # 約 320 字元
    chunks = chunk_text(text, source="test", config=ChunkingConfig(
        chunk_size_chars=50, chunk_overlap_chars=10
    ))
    assert len(chunks) >= 2


def test_overlap_chars_appear_in_consecutive_chunks() -> None:
    """重疊區段應出現在相鄰片段中，確保語意連貫性。"""
    text = "前十字韌帶重建術後第一週。膝關節屈曲角度目標為九十度。術後疼痛控制非常重要。每日冰敷二十分鐘。"
    config = ChunkingConfig(chunk_size_chars=30, chunk_overlap_chars=10)
    chunks = chunk_text(text, source="acl", config=config)

    if len(chunks) >= 2:
        tail_of_first = chunks[0].text[-10:]
        head_of_second = chunks[1].text[:20]
        assert any(ch in head_of_second for ch in tail_of_first if ch.strip())


def test_chunk_ids_are_unique() -> None:
    sentence = "每次復健前應進行暖身活動。"
    text = sentence * 30
    chunks = chunk_text(text, source="doc", config=ChunkingConfig(
        chunk_size_chars=40, chunk_overlap_chars=5
    ))
    ids = [c.chunk_id for c in chunks]
    assert len(ids) == len(set(ids))


def test_overlap_larger_than_chunk_size_raises() -> None:
    with pytest.raises(ValueError, match="chunk_overlap_chars"):
        chunk_text("測試", source="t", config=ChunkingConfig(
            chunk_size_chars=50, chunk_overlap_chars=60
        ))


def test_chunk_indices_are_sequential() -> None:
    text = "復健訓練需要耐心。" * 20
    chunks = chunk_text(text, source="s", config=ChunkingConfig(
        chunk_size_chars=30, chunk_overlap_chars=5
    ))
    for i, chunk in enumerate(chunks):
        assert chunk.chunk_index == i
