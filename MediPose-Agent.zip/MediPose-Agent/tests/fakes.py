"""
測試輔助模組：模擬 ultralytics YOLO 推論結果的最小介面。

僅實作 LowerBodyJointExtractor 實際呼叫到的方法
（.cpu()、.numpy()、.mean(dim=)、.argmax()、.item()、__len__），
讓單元測試不需安裝 torch / 下載模型權重即可驗證提取邏輯正確性。
"""
from __future__ import annotations

from typing import Any

import numpy as np


class FakeTensor:
    """模擬 torch.Tensor 的最小子集介面，底層以 numpy 陣列運算。"""

    def __init__(self, array: np.ndarray) -> None:
        self._array = array

    def cpu(self) -> "FakeTensor":
        return self

    def numpy(self) -> np.ndarray:
        return self._array

    def mean(self, dim: int) -> "FakeTensor":
        return FakeTensor(self._array.mean(axis=dim))

    def argmax(self) -> "FakeTensor":
        return FakeTensor(np.array(self._array.argmax()))

    def item(self) -> Any:
        return self._array.item()

    def __len__(self) -> int:
        return len(self._array)

    def __getitem__(self, idx: int) -> "FakeTensor":
        return FakeTensor(self._array[idx])


class FakeKeypoints:
    """模擬 ultralytics Results.keypoints 物件。"""

    def __init__(self, xy: np.ndarray, conf: np.ndarray) -> None:
        """
        Args:
            xy: shape (num_persons, 17, 2)
            conf: shape (num_persons, 17)
        """
        self.xy = FakeTensor(xy)
        self.conf = FakeTensor(conf)


class FakeYoloResult:
    """模擬 ultralytics Results 物件。"""

    def __init__(self, keypoints: FakeKeypoints | None) -> None:
        self.keypoints = keypoints


def make_single_person_result(
    confidence: float = 0.9, x_offset: float = 0.0
) -> FakeYoloResult:
    """建立單人、17 個關鍵點皆有效的假推論結果，座標依索引遞增以利驗證。"""
    xy = np.array([[[float(i) + x_offset, float(i) * 2] for i in range(17)]])
    conf = np.full((1, 17), confidence)
    return FakeYoloResult(FakeKeypoints(xy, conf))


def make_no_person_result() -> FakeYoloResult:
    """建立未偵測到任何人物的假推論結果。"""
    xy = np.zeros((0, 17, 2))
    conf = np.zeros((0, 17))
    return FakeYoloResult(FakeKeypoints(xy, conf))


def make_multi_person_result() -> FakeYoloResult:
    """建立兩人同框、信心值不同的假推論結果，用於驗證主要人物選取邏輯。"""
    xy = np.stack(
        [
            np.array([[float(i), float(i) * 2] for i in range(17)]),  # person 0
            np.array([[float(i) + 100, float(i) * 2 + 100] for i in range(17)]),  # person 1
        ]
    )
    conf = np.stack(
        [
            np.full(17, 0.3),  # person 0: 低信心
            np.full(17, 0.9),  # person 1: 高信心，應被選為主要對象
        ]
    )
    return FakeYoloResult(FakeKeypoints(xy, conf))
